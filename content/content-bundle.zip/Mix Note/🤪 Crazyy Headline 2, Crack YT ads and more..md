Tag :- [[ReadItLater]] , 
Added :- 2023-03-18

-----
# [🤪 Crazyy Headline 2, Crack YT ads and more.](https://therohitkumar.substack.com/p/crazyy-headline-2-crack-yt-ads-and)

1.  **Create Crazyy Headline 2 for Search Ads to increase CTR%**
    
    1.  Search the keyword where you want your ad to be there.
        
    2.  Check headline 2 for all the competitors.
        
    3.  Is your headline 2 and others speaking the same?
        
    4.  If yes, recreate the headline to elicit a response"Damn, are you serious?!"
        
    5.  It can be a crazy value prop, offer or cta but it has to be “crazyy”.
        
    6.  Check *[this](https://www.linkedin.com/posts/rohitkumar15_performancemarketing-googleads-ppc-activity-7038353753095233536-p-EF?utm_source=share&utm_medium=member_desktop)* for more context  
        
2.  **Crack Youtube Ads in 1 minute**
    
    1.  Find 2 hidden audiences on YT with a near 100% success rate.
        
    2.  Go to “Search ads” > Go to your “Brand campaign”
        
    3.  Click on “Insights” on the left > Go to “Audience insights”
        
    4.  Click on the “Conversions” tab.
        
    5.  Sort “% share conversions” from high to low > Note the 1st audience.
        
    6.  Sort “Index” from high to low > Note the 2nd audience.
        
    7.  Run both these audiences as experiments
        
    8.  Check *[this](https://www.linkedin.com/posts/rohitkumar15_crack-youtube-ads-in-1-minute-activity-7039444693541130240-_3-L?utm_source=share&utm_medium=member_desktop)* for more context.  
        
3.  **Add a budget for experiments in your media plan** for the biz requirements for the next 3-6 months
    
    1.  Discuss revenue projections for the next 6 months.
        
    2.  Backtrack to know contribution from paid efforts month on month.
        
    3.  Experiment with newer audiences in the running ad platform or explore newer channels.
        
    4.  Understand how your team needs to shape up. Need content writers, designers, video editors, freelancers etc?  
        
4.  **Switch off Audience Network as placement in your Facebook ads**
    
    1.  The intent of the traffic is low from AN, hence keep it OFF
        
    2.  I am yet to find a use case where keeping it ON, had any benefit. (Let’s not say scale :P, as we intend for quality scale)
        
    3.  If you find any use case, do reply.  
        
5.  **Test an informational ad creative static or video**
    
    1.  Provide 1 value ad hack in the creative.
        
    2.  No fancy or clever tactic, it has to be pure value add.
        
        1.  Ex: For a brand that sells an excel course: Give 1 excel hack in 5 seconds.
            
    3.  It should yearn them to know more by clicking on the ad.
        
    4.  How does it work:
        
        1.  Since it is a value add, people will engage with your ad post.
            
        2.  It helps in increasing “reach” and reducing CPMs.
            

1.  [Framework](https://www.linkedin.com/posts/syed-adil-growth_the-growth-trilemma-activity-7038516442530471936-dySM?utm_source=share&utm_medium=member_desktop) to visualize growth.
    
2.  [The 4-second formula](https://www.linkedin.com/posts/rob-hoffman-ceo_you-have-1-4-seconds-to-hook-your-audience-activity-7039965839655096320-i4oh?utm_source=share&utm_medium=member_desktop) for short form, vertical video.
    
3.  [17 Books](https://www.linkedin.com/posts/rohitkumar15_performancemarketing-digitalmarketing-growthhacking-activity-7038719916648136705-V6vF?utm_source=share&utm_medium=member_desktop) I recommend to Performance marketers and growth folks
    

This group is my second brain. I record all that I learn by posting on this group.  
Most Imp: You get a free & exclusive invite to all my sessions here! Join now 👇

[Join Whatsapp Group](https://chat.whatsapp.com/JcagIPnRH5YGImuk2vbSdo)

If you love this newsletter or have any suggestions to make it better, please reply to this mail.

I read and reply to every mail :)

Rohit

Thank you for reading Performance Marketing & Growth. If you love it, do **share** it :)

[Share](https://therohitkumar.substack.com/p/crazyy-headline-2-crack-yt-ads-and?utm_source=substack&utm_medium=email&utm_content=share&action=share)