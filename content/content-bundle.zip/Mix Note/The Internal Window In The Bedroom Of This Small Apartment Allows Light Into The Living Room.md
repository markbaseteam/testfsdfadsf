[[ReadItLater]] [[Article]]

# [The Internal Window In The Bedroom Of This Small Apartment Allows Light Into The Living Room](https://www.contemporist.com/the-internal-window-in-the-bedroom-of-this-small-apartment-allows-light-into-the-living-room/)

[![A small apartment with a wood platform bed and lots of natural light.](https://www.contemporist.com/wp-content/uploads/2022/07/small-apartment-bedroom-interior-design-300722-905-01.jpg)](https://www.contemporist.com/the-internal-window-in-the-bedroom-of-this-small-apartment-allows-light-into-the-living-room/)

Ada Wong & Eric Liu of interior design firm [littleMORE](https://littlemoredesign.net/) have shared one of their latest projects, a small 352 square foot (32sqm) apartment in Hong Kong, that’s been designed for a young couple who wanted to refresh their own apartment with more natural light.

Stepping inside, there’s a small entryway with storage cabinets and a bench with coat hooks above.

![Stepping inside this small apartment, there's an entryway with storage cabinets and a bench with coat hooks above.](https://www.contemporist.com/wp-content/uploads/2022/07/small-apartment-entryway-coat-hooks-300722-910-01.jpg)

![Stepping inside this small apartment, there's an entryway with storage cabinets and a bench with coat hooks above.](https://www.contemporist.com/wp-content/uploads/2022/07/small-apartment-entryway-coat-hooks-300722-910-02.jpg)

As the couple works at home a lot and they don’t want to be working in separated spaces, so the open plan arrangement of the apartment allows them to each have their own space, like working in the living room or at the desk, but at the same time be close to each other.

![A small apartment includes a living space, work area, and separate bedroom behind a glass wall.](https://www.contemporist.com/wp-content/uploads/2022/07/small-living-room-300722-912-01.jpg)

The desk, which is filled with natural light from multiple windows, has been built-in to make the most of the space. An open shelving unit, as well as cabinets below, adds storage space.

![This desk, which is filled with natural light from multiple windows, has been built-in to make the most of the space. An open shelving unit as well as cabinets below adds storage space.](https://www.contemporist.com/wp-content/uploads/2022/07/small-apartment-home-office-desk-300722-913-01.jpg)

The black-framed window and door by the desk creates a separate room for the bedroom, without blocking the light.

![The black-framed window and door by the desk creates a separate room for the bedroom, without blocking the light.](https://www.contemporist.com/wp-content/uploads/2022/07/small-apartment-home-office-desk-interior-window-300722-913-02.jpg)

In the bedroom, the bed is raised up on a wood platform, that also includes bedside tables. By the windows, there are additional wood platforms that allow for extra seating and places to display plants. At the opposite end of the bedroom, there’s a bookshelf as well as a closet.

![In the bedroom, the bed is raised up on a wood platform, that also includes bedside tables. By the windows there's additional wood platforms that allows for extra seating and places to display plants.](https://www.contemporist.com/wp-content/uploads/2022/07/small-apartment-bedroom-platform-bed-300722-917-01.jpg)

![In this small bedroom, a wood closet and white bookshelf make the most of the available space.](https://www.contemporist.com/wp-content/uploads/2022/07/small-apartment-bedroom-platform-bed-300722-917-02.jpg)

![A wood closet and white bookshelf in a small apartment makes the most of the available space.](https://www.contemporist.com/wp-content/uploads/2022/07/small-apartment-bedroom-closet-shelving-300722-918-01.jpg)

![A wood closet and white bookshelf in a small apartment makes the most of the available space.](https://www.contemporist.com/wp-content/uploads/2022/07/small-apartment-bedroom-closet-shelving-300722-918-02.jpg)

Out in the main living area, and there’s a small kitchen tucked in an alcove. Included in the kitchen are minimalist white cabinets, a grey backsplash, and a washing machine.

![A small kitchen with a washing machine and under cabinet lighting.](https://www.contemporist.com/wp-content/uploads/2022/07/small-apartment-white-kitchen-300722-908-01.jpg)

![A small kitchen with white minimalist cabinets.](https://www.contemporist.com/wp-content/uploads/2022/07/small-apartment-white-kitchen-300722-908-02.jpg)

The bathroom is hidden behind a door that almost blends into the wall between the kitchen and bedroom. The small bathroom has a toilet, shower, vanity area, window, and storage.

![The bathroom in this small apartment is hidden behind a door that almost blends into the wall between the kitchen and bedroom. The small bathroom has a toilet, shower, a vanity area, a window, and a storage.](https://www.contemporist.com/wp-content/uploads/2022/07/small-apartment-bathroom-300722-856-01.jpg)

###### Photography by Michael Perini