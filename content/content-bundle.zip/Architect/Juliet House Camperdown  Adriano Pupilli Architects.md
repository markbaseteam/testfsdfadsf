[[ReadItLater]] [[Article]]

Added :- 2023-02-16
# [Juliet House Camperdown / Adriano Pupilli Architects](https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects)

Juliet House Camperdown / Adriano Pupilli Architects

[![Juliet House Camperdown / Adriano Pupilli Architects - Exterior Photography, Facade](https://images.adsttc.com/media/images/62f2/805d/d089/3a01/70d3/e346/newsletter/juliet-house-camperdown-adriano-pupilli-architects_1.jpg?1660059793)](https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects/62f2805dd0893a0170d3e346-juliet-house-camperdown-adriano-pupilli-architects-photo)

© Simon Whitbread

[![Juliet House Camperdown / Adriano Pupilli Architects - Interior Photography, Kitchen, Table, Chair](https://images.adsttc.com/media/images/62f2/8066/2c7e/a301/6f76/1973/thumb_jpg/juliet-house-camperdown-adriano-pupilli-architects_9.jpg?1660059803 "© Simon Whitbread")](https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects/62f280662c7ea3016f761973-juliet-house-camperdown-adriano-pupilli-architects-photo)[![Juliet House Camperdown / Adriano Pupilli Architects - Interior Photography, Bathroom, Bathtub, Windows, Sink](https://images.adsttc.com/media/images/62f2/8076/d089/3a01/70d3/e348/thumb_jpg/juliet-house-camperdown-adriano-pupilli-architects_11.jpg?1660059820 "© Simon Whitbread")](https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects/62f28076d0893a0170d3e348-juliet-house-camperdown-adriano-pupilli-architects-photo)[![Juliet House Camperdown / Adriano Pupilli Architects - Interior Photography, Windows, Glass, Handrail](https://images.adsttc.com/media/images/62f2/8044/d089/3a01/70d3/e344/thumb_jpg/juliet-house-camperdown-adriano-pupilli-architects_5.jpg?1660059770 "© Simon Whitbread")](https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects/62f28044d0893a0170d3e344-juliet-house-camperdown-adriano-pupilli-architects-photo)[![Juliet House Camperdown / Adriano Pupilli Architects - Interior Photography, Living Room, Sofa, Lighting, Table, Brick, Chair, Beam](https://images.adsttc.com/media/images/62f2/804a/d089/3a01/70d3/e345/thumb_jpg/juliet-house-camperdown-adriano-pupilli-architects_2.jpg?1660059775 "© Simon Whitbread")](https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects/62f2804ad0893a0170d3e345-juliet-house-camperdown-adriano-pupilli-architects-photo)[![Juliet House Camperdown / Adriano Pupilli Architects - More Images](https://images.adsttc.com/media/images/62f2/805d/d089/3a01/70d3/e346/newsletter/juliet-house-camperdown-adriano-pupilli-architects_1.jpg?1660059793)\+ 13](https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects/62f2805dd0893a0170d3e346-juliet-house-camperdown-adriano-pupilli-architects-photo)

-   Area Area of this architecture project Area :  [125](https://www.archdaily.com/search/projects/min_area/100/max_area/150?ad_name=project-specs&ad_medium=single) m²
-   Year Completion year of this architecture project Year :  [2021](https://www.archdaily.com/search/projects/year/2021?ad_name=project-specs&ad_medium=single)
-   Photographs
-   Manufacturers Brands with products used in this architecture project
    
    Manufacturers :  Artedomus, Astro Lighting, Briggs, Caroma, Phoenix Tapware
    

More SpecsLess Specs

[![Juliet House Camperdown / Adriano Pupilli Architects - Interior Photography, Windows, Glass, Handrail](https://images.adsttc.com/media/images/62f2/8044/d089/3a01/70d3/e344/medium_jpg/juliet-house-camperdown-adriano-pupilli-architects_5.jpg?1660059770)](https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects/62f28044d0893a0170d3e344-juliet-house-camperdown-adriano-pupilli-architects-photo)

© Simon Whitbread

*Text description provided by the architects.* The project brief was to extend an existing Federation-style heritage home to create a generous, light, and lofty contemporary living space that connects with the rear garden and laneway, a parent’s retreat + ensuite upstairs, and an additional bedroom kids’ bedroom. A vast increase in floor area was required however the scale and materiality of the extension needed to sit sympathetically against the character of the original house and be discrete from the front streetscape.

[![Juliet House Camperdown / Adriano Pupilli Architects - Exterior Photography, Windows, Brick, Facade, Courtyard](https://images.adsttc.com/media/images/62f2/8085/d089/3a01/70d3/e34b/medium_jpg/juliet-house-camperdown-adriano-pupilli-architects_10.jpg?1660059836)](https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects/62f28085d0893a0170d3e34b-juliet-house-camperdown-adriano-pupilli-architects-photo)

© Simon Whitbread

[![Juliet House Camperdown / Adriano Pupilli Architects - Image 15 of 18](https://images.adsttc.com/media/images/62f2/7f8a/d089/3a01/70d3/e340/medium_jpg/rob28-proposed-ground-floor-plan-2.jpg?1660059567)](https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects/62f27f8ad0893a0170d3e340-juliet-house-camperdown-adriano-pupilli-architects-plan-ground-floor)

Plan - Ground floor

[![Juliet House Camperdown / Adriano Pupilli Architects - Interior Photography, Kitchen, Table, Chair](https://images.adsttc.com/media/images/62f2/8066/2c7e/a301/6f76/1973/medium_jpg/juliet-house-camperdown-adriano-pupilli-architects_9.jpg?1660059803)](https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects/62f280662c7ea3016f761973-juliet-house-camperdown-adriano-pupilli-architects-photo)

© Simon Whitbread

[![Juliet House Camperdown / Adriano Pupilli Architects - Image 16 of 18](https://images.adsttc.com/media/images/62f2/7f8a/d089/3a01/70d3/e341/medium_jpg/rob28-proposed-first-floor-plan-1.jpg?1660059568)](https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects/62f27f8ad0893a0170d3e341-juliet-house-camperdown-adriano-pupilli-architects-plan-1st-floor)

Plan - 1st floor

[![Juliet House Camperdown / Adriano Pupilli Architects - Exterior Photography, Brick, Facade, Handrail](https://images.adsttc.com/media/images/62f2/8063/2c7e/a301/6f76/1971/medium_jpg/juliet-house-camperdown-adriano-pupilli-architects_3.jpg?1660059765)](https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects/62f280632c7ea3016f761971-juliet-house-camperdown-adriano-pupilli-architects-photo)

© Simon Whitbread

Challenges included working within tight heritage controls imposed by the Council as well as careful massing of new internal spaces so that the original home is not dominated by the new works, whilst creating a new extension that responds to the context and needs of a young family and clients desire for open plan living and contemporary finishes.

[![Juliet House Camperdown / Adriano Pupilli Architects - Interior Photography, Bathroom, Bathtub, Windows, Sink](https://images.adsttc.com/media/images/62f2/8076/d089/3a01/70d3/e348/medium_jpg/juliet-house-camperdown-adriano-pupilli-architects_11.jpg?1660059820)](https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects/62f28076d0893a0170d3e348-juliet-house-camperdown-adriano-pupilli-architects-photo)

© Simon Whitbread

A gable roof form was employed which compliments the scale and geometry of the original house, with angled roof planes towards the street elevation which soften the transition from the new higher gable and the original roof. The floor level steps down with the site slope towards the rear to create an opportunity for high ceilings in the living area and bedrooms above.

[![Juliet House Camperdown / Adriano Pupilli Architects - Interior Photography, Living Room, Sofa, Lighting, Table, Brick, Chair, Beam](https://images.adsttc.com/media/images/62f2/804a/d089/3a01/70d3/e345/medium_jpg/juliet-house-camperdown-adriano-pupilli-architects_2.jpg?1660059775)](https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects/62f2804ad0893a0170d3e345-juliet-house-camperdown-adriano-pupilli-architects-photo)

© Simon Whitbread

[![Juliet House Camperdown / Adriano Pupilli Architects - Image 18 of 18](https://images.adsttc.com/media/images/62f2/7f88/2c7e/a301/6f76/196e/medium_jpg/robe28-proposed-sections-4.jpg?1660059565)](https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects/62f27f882c7ea3016f76196e-juliet-house-camperdown-adriano-pupilli-architects-sections)

Sections

[![Juliet House Camperdown / Adriano Pupilli Architects - Exterior Photography, Facade, Windows](https://images.adsttc.com/media/images/62f2/8082/d089/3a01/70d3/e34a/medium_jpg/juliet-house-camperdown-adriano-pupilli-architects_4.jpg?1660059831)](https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects/62f28082d0893a0170d3e34a-juliet-house-camperdown-adriano-pupilli-architects-photo)

© Simon Whitbread

Highlights include working sympathetically with the character-filled house, drawing out and celebrating aspects of the original house through repurposed materials, and exploring some exciting new geometries that emerge from the original.

[![Juliet House Camperdown / Adriano Pupilli Architects - Exterior Photography, Brick, Fence, Facade, Windows](https://images.adsttc.com/media/images/62f2/8071/d089/3a01/70d3/e347/medium_jpg/juliet-house-camperdown-adriano-pupilli-architects_13.jpg?1660059815)](https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects/62f28071d0893a0170d3e347-juliet-house-camperdown-adriano-pupilli-architects-photo)

© Simon Whitbread

## Project gallery

See allShow less

About this office

![](https://images.adsttc.com/media/images/62f2/8066/2c7e/a301/6f76/1973/thumb_jpg/juliet-house-camperdown-adriano-pupilli-architects_9.jpg?1660059803)

Published on August 13, 2022

**Cite:** "Juliet House Camperdown / Adriano Pupilli Architects" 13 Aug 2022. ArchDaily. Accessed . <https://www.archdaily.com/986914/juliet-house-camperdown-adriano-pupilli-architects> ISSN 0719-8884

## 世界上最受欢迎的建筑网站现已推出你的母语版本!

### 想浏览ArchDaily中国吗?

[是](https://www.archdaily.cn/cn?ad_name=home_cn_redirect&ad_medium=popup)否

### Did you know?

You'll now receive updates based on what you follow! Personalize your stream and start following your favorite authors, offices and users.

---