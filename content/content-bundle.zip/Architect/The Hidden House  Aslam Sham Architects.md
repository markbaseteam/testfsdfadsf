[[ReadItLater]] [[Article]]

Added :- 2023-02-16
# [The Hidden House / Aslam Sham Architects](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects)

The Hidden House / Aslam Sham Architects

[![The Hidden House / Aslam Sham Architects - Exterior Photography, Garden](https://images.adsttc.com/media/images/62f5/56d8/f08d/d101/6fcf/816e/newsletter/the-hidden-house-aslam-sham-architects_1.jpg?1660245773)](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f556d8f08dd1016fcf816e-the-hidden-house-aslam-sham-architects-photo)

© Justin Sebastian

[![The Hidden House / Aslam Sham Architects - Interior Photography, Kitchen, Facade, Garden, Beam, Courtyard](https://images.adsttc.com/media/images/62f5/5732/f08d/d101/6fcf/8177/thumb_jpg/the-hidden-house-aslam-sham-architects_10.jpg?1660245867 "© Justin Sebastian")](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f55732f08dd1016fcf8177-the-hidden-house-aslam-sham-architects-photo)[![The Hidden House / Aslam Sham Architects - Interior Photography, Kitchen, Countertop](https://images.adsttc.com/media/images/62f5/571f/f08d/d101/6fcf/8175/thumb_jpg/the-hidden-house-aslam-sham-architects_13.jpg?1660245844 "© Justin Sebastian")](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f5571ff08dd1016fcf8175-the-hidden-house-aslam-sham-architects-photo)[![The Hidden House / Aslam Sham Architects - Interior Photography, Kitchen, Windows, Chair, Courtyard](https://images.adsttc.com/media/images/62f5/5737/f08d/d101/6fcf/8178/thumb_jpg/the-hidden-house-aslam-sham-architects_14.jpg?1660245872 "© Justin Sebastian")](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f55737f08dd1016fcf8178-the-hidden-house-aslam-sham-architects-photo)[![The Hidden House / Aslam Sham Architects - Exterior Photography, Windows, Facade, Garden, Courtyard](https://images.adsttc.com/media/images/62f5/56b4/f08d/d101/6fcf/816a/thumb_jpg/the-hidden-house-aslam-sham-architects_2.jpg?1660245742 "© Justin Sebastian")](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f556b4f08dd1016fcf816a-the-hidden-house-aslam-sham-architects-photo)[![The Hidden House / Aslam Sham Architects - More Images](https://images.adsttc.com/media/images/62f5/56d8/f08d/d101/6fcf/816e/newsletter/the-hidden-house-aslam-sham-architects_1.jpg?1660245773)\+ 15](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f556d8f08dd1016fcf816e-the-hidden-house-aslam-sham-architects-photo)

-   Area Area of this architecture project Area :  [5800](https://www.archdaily.com/search/projects/min_area/431/max_area/646?ad_name=project-specs&ad_medium=single) ft²
-   Year Completion year of this architecture project Year :  [2021](https://www.archdaily.com/search/projects/year/2021?ad_name=project-specs&ad_medium=single)
-   Photographs
-   Manufacturers Brands with products used in this architecture project
    
    Manufacturers :   Tostem India, Hipzone Automation, Hybec, Kajaria ceramics, Suzuka
    

More SpecsLess Specs

[![The Hidden House / Aslam Sham Architects - Exterior Photography, Windows, Facade, Garden, Courtyard](https://images.adsttc.com/media/images/62f5/56b4/f08d/d101/6fcf/816a/medium_jpg/the-hidden-house-aslam-sham-architects_2.jpg?1660245742)](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f556b4f08dd1016fcf816a-the-hidden-house-aslam-sham-architects-photo)

© Justin Sebastian

*Text description provided by the architects.* The Hidden House. Let these words paint a picture of a secretive abode shielded from plain sight, nothing could be farther from the truth. For this is “a house that does not try to blend in; it wants to stand out from the rest, grab attention and take in those glances from the street,” declare architects Aslam Karadan and Sham Salim of eponymous Kozhikode-based practice Aslam.Sham Architects. “It is unapologetically unique with its form and intends to capture the intrigue of the passers-by—just like the client wanted it to.” The ‘hidden’ part of the moniker, they explain, comes from the home’s disguised scale: a three-level home that creates the illusion of being a smaller, two-Storey structure.

[![The Hidden House / Aslam Sham Architects - Exterior Photography, Facade, Garden, Courtyard](https://images.adsttc.com/media/images/62f5/56c3/ac3f/210e/ae6f/2429/medium_jpg/the-hidden-house-aslam-sham-architects_3.jpg?1660245756)](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f556c3ac3f210eae6f2429-the-hidden-house-aslam-sham-architects-photo)

© Justin Sebastian

The functional brief was pretty standard and straightforward, i.e., they wanted a 5 BHK house with an additional room to be used as a home theatre, a swimming pool, and other standard amenities. The aesthetic brief is however something that we as architects loved and found challenging at the same time. The client, as mentioned earlier, is a self-made successful entrepreneur and wanted to build a house that made a statement from the first look but at the same time didn’t compromise on the functionalities too much. We were given the task to come up with something that is out of the box yet not fully experimental. This brief combined with the highly contoured nature of the site which was sloping downwards steeply from the front of the site to the rear is what led to the rather unique form/ facade of the building and its name, the Hidden House. The scale of the house remains largely hidden to an onlooker from the street but at the same time, it does stand out with its atypical form and creates that curiosity in their minds to know what’s behind that peculiar front facade/form.

[![The Hidden House / Aslam Sham Architects - Interior Photography, Windows, Garden](https://images.adsttc.com/media/images/62f5/570b/f08d/d101/6fcf/8172/medium_jpg/the-hidden-house-aslam-sham-architects_6.jpg?1660245827)](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f5570bf08dd1016fcf8172-the-hidden-house-aslam-sham-architects-photo)

© Justin Sebastian

[![The Hidden House / Aslam Sham Architects - Image 17 of 20](https://images.adsttc.com/media/images/62f5/5657/f08d/d101/6fcf/8166/medium_jpg/2-groundfloor-2.jpg?1660245642)](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f55657f08dd1016fcf8166-the-hidden-house-aslam-sham-architects-plan-ground-floor)

Plan - Ground floor

[![The Hidden House / Aslam Sham Architects - Interior Photography, Kitchen, Countertop](https://images.adsttc.com/media/images/62f5/571f/f08d/d101/6fcf/8175/medium_jpg/the-hidden-house-aslam-sham-architects_13.jpg?1660245844)](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f5571ff08dd1016fcf8175-the-hidden-house-aslam-sham-architects-photo)

© Justin Sebastian

As far as the spatial configuration is concerned, the basic zoning has been done based on the proximity of the road which goes along the front boundary of the site. The first zone is the public zone which has visibility from the street and this hosts the front sit-out as well as the formal living space which is primarily intended for visitors/guests. Then comes the next zone which is the semipublic zone which is the core activity hub and what we would like to call the soul of the house which has the skylit Koi Pond around which all the core activity spaces of the house are planned, viz, the family living space, the dining space as well as the kitchen.

[![The Hidden House / Aslam Sham Architects - Interior Photography, Kitchen, Sofa, Stairs, Table, Chair, Handrail, Beam](https://images.adsttc.com/media/images/62f5/5734/ac3f/2126/f458/75d9/medium_jpg/the-hidden-house-aslam-sham-architects_11.jpg?1660245867)](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f55734ac3f2126f45875d9-the-hidden-house-aslam-sham-architects-photo)

© Justin Sebastian

And next comes the private zone, which houses the bedrooms, home theatre as well as the swimming pool which is placed at the rear end of the site and hence is completely cut off from the outsiders. Also, regarding the spatial configuration, you have to understand this is not done on a planar site, this is a highly contoured site, so we could achieve this zoning differentiation with the levels too. However, from the master bedroom, a balcony opens up into the front of the house which was a requirement from the Client’s end that they needed to see from the main entrance to the site from the master bedroom. The plot being L shaped has a portion that protrudes outward at the rear, this portion is what is used to accommodate the garage. The driveway and the garage areas are given hardscaping while more green landscaping is provided in the front yard

[![The Hidden House / Aslam Sham Architects - Image 18 of 20](https://images.adsttc.com/media/images/62f5/565c/f08d/d101/6fcf/8168/medium_jpg/3-firstfloor-3.jpg?1660245650)](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f5565cf08dd1016fcf8168-the-hidden-house-aslam-sham-architects-plan-1st-floor)

Plan - 1st floor

The most challenging (as well as the most exciting) part of this project was definitely the process of manipulating this highly contoured site into having a house with multiple levels whilst also attempting to reduce the number of climbs the user would have to go through through on a regular day. This has been achieved by splitting different zones into multiple levels. The primary entry to the house is into the public zone, which is at a level of just a couple of steps from the approaching ground level at the front, the one between the massive granite feature walls in the front which sort of plays with the sense of scale to a visitor. This level has the formal living room as well as the prayer(names) room, both of which are primarily intended for visitors.

[![The Hidden House / Aslam Sham Architects - Interior Photography, Table, Chair, Stairs, Handrail, Beam](https://images.adsttc.com/media/images/62f5/5737/ac3f/210e/ae6f/2438/medium_jpg/the-hidden-house-aslam-sham-architects_12.jpg?1660245873)](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f55737ac3f210eae6f2438-the-hidden-house-aslam-sham-architects-photo)

© Justin Sebastian

The secondary entry, the arched entry from the side, is the one intended for the family the most as it is accessing the primary activity core of the house in just one step. You just need to take one step down from that level to reach the semipublic zone, which houses the Koi Pond, Family living space, Dining space, and Kitchen. It is from this level that the access to the multiple bedroom blocks which are placed on three levels. So, from the common area level, it is only half a floor ascent as well as the descent to the 2 levels which have 2 bedrooms each. The master bedroom, as well as the home theatre, is at the highest level with a study space as well as a utility terrace at a mid-level between these two levels. So, the house in total is split into 6-7 levels in order to accommodate all of the client's spatial requirements without tampering with the existing site levels too much.

[![The Hidden House / Aslam Sham Architects - Interior Photography, Kitchen, Facade, Garden, Beam, Courtyard](https://images.adsttc.com/media/images/62f5/5732/f08d/d101/6fcf/8177/medium_jpg/the-hidden-house-aslam-sham-architects_10.jpg?1660245867)](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f55732f08dd1016fcf8177-the-hidden-house-aslam-sham-architects-photo)

© Justin Sebastian

[![The Hidden House / Aslam Sham Architects - Image 20 of 20](https://images.adsttc.com/media/images/62f5/5657/f08d/d101/6fcf/8165/medium_jpg/6-section-6.jpg?1660245639)](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f55657f08dd1016fcf8165-the-hidden-house-aslam-sham-architects-section)

Section

There is also tertiary access to the house from the lowermost level, which is the same as the pool level, the driveway of extends to the rear of the site and there is a porch from which the house can be accessed and there are two bedrooms also at this level. This level is accessible via a ramp and the 2 bedrooms here with car access ensure the house is accessible easily for the elderly as well as the differently abled. The lift well has been constructed in the house and hence there is always a provision to add a lift, later on, to access all the levels comfortably.

[![The Hidden House / Aslam Sham Architects - Interior Photography, Windows, Facade, Brick, Arch](https://images.adsttc.com/media/images/62f5/573a/f08d/d101/6fcf/8179/medium_jpg/the-hidden-house-aslam-sham-architects_8.jpg?1660245929)](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f5573af08dd1016fcf8179-the-hidden-house-aslam-sham-architects-photo)

© Justin Sebastian

[![The Hidden House / Aslam Sham Architects - Image 16 of 20](https://images.adsttc.com/media/images/62f5/5654/f08d/d101/6fcf/8164/medium_jpg/1-basement-1.jpg?1660245629)](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f55654f08dd1016fcf8164-the-hidden-house-aslam-sham-architects-plan-basement)

Plan - Basement

The material and color palette has mostly been decided to give the house a very simple yet sophisticated character. Apart from the whites, natural textures of random rubble masonry, wood, the multiple textured finish natural stone floorings such as granite, Kota stones, deck wood, etc were chosen to give character to each space and differentiate them visually without compromising on the open feel of the space. Accents of green throughout the house with planters also help in creating a warm cozy feel to the user. We like exposing the true character of materials rather than mimicking them into something else and hence the concrete roof slabs, as well as the retaining walls, are given concrete textures, however, it is a more polished concrete finish for the interiors whereas it's a rougher tone for the exterior.

[![The Hidden House / Aslam Sham Architects - Interior Photography, Kitchen, Windows, Chair, Courtyard](https://images.adsttc.com/media/images/62f5/5737/f08d/d101/6fcf/8178/medium_jpg/the-hidden-house-aslam-sham-architects_14.jpg?1660245872)](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f55737f08dd1016fcf8178-the-hidden-house-aslam-sham-architects-photo)

© Justin Sebastian

Lighting strategy is something that is fundamental to all our designs, we design for maximum natural lighting throughout the day which we believe creates mental well-being for the user subconsciously. Ideally, we want artificial lights to be used only once the Sun goes down. The harsh east and west lights are blocked off from falling directly into the house and are taken in a diffused manner via louvered screens outside the windows. In night, subtle ambient lighting is provided in the interiors accounting for optimal comfort to the user. The exteriors however are given slightly more dramatic lighting for the structure to stand out to an onlooker from the street, which was something the client wished for.

[![The Hidden House / Aslam Sham Architects - Exterior Photography, Windows, Door, Facade](https://images.adsttc.com/media/images/62f5/5704/f08d/d101/6fcf/8171/medium_jpg/the-hidden-house-aslam-sham-architects_7.jpg?1660245823)](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f55704f08dd1016fcf8171-the-hidden-house-aslam-sham-architects-photo)

© Justin Sebastian

To be honest, we couldn’t have found a more accommodating client than these two as they were completely taken in by the concept, we presented to them and barely asked for any changes barring the minor tweaks in the interior. This project is one of the perfect examples of how much the final product can be elevated when the architects and the clients are in synch. So, it was more like a dream that all of us saw together. It would be extremely hard to pick one spot as the favorite, but if we have to pick one it would be the main activity core of the house which houses all of the common spaces around the skylit Koi Pond.

[![The Hidden House / Aslam Sham Architects - Exterior Photography, Facade, Garden](https://images.adsttc.com/media/images/62f5/5711/f08d/d101/6fcf/8173/medium_jpg/the-hidden-house-aslam-sham-architects_5.jpg?1660245837)](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f55711f08dd1016fcf8173-the-hidden-house-aslam-sham-architects-photo)

© Justin Sebastian

The outdoor deck from the dining room which overlooks the pool area below is another favorite. The client, who as mentioned earlier, is an entrepreneur and spends most of the time at home itself since his work happens online, tells us he loves spending time in this house, and that he keeps finding new spots and feelings in each space with every passing day to the extent that he hates it when he has to leave for work-related meetings occasionally. Most of the furniture is customized as per the space and design theme of the house barring a few loose furniture and other show pieces which were sourced together by the clients and the architects over a zillion showroom visits.

[![The Hidden House / Aslam Sham Architects - Exterior Photography, Facade, Garden, Courtyard](https://images.adsttc.com/media/images/62f5/56f9/f08d/d101/6fcf/8170/medium_jpg/the-hidden-house-aslam-sham-architects_4.jpg?1660245810)](https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects/62f556f9f08dd1016fcf8170-the-hidden-house-aslam-sham-architects-photo)

© Justin Sebastian

**Cite:** "The Hidden House / Aslam Sham Architects" 12 Aug 2022. ArchDaily. Accessed . <https://www.archdaily.com/987068/the-hidden-house-aslam-sham-architects> ISSN 0719-8884