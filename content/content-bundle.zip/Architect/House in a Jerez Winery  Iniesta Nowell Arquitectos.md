[[ReadItLater]] [[Article]]

Added :- 2023-02-16
# [House in a Jerez Winery / Iniesta Nowell Arquitectos](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos)

House in a Jerez Winery / Iniesta Nowell Arquitectos

[![House in a Jerez Winery / Iniesta Nowell Arquitectos - Interior Photography, Living Room, Table, Windows, Beam](https://images.adsttc.com/media/images/62f4/0a39/3838/8501/6ffb/f222/medium_jpg/vivienda-en-una-bodega-de-jerez-iniesta-nowell-arquitectos_4.jpg?1660160617)](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos/62f40a39383885016ffbf222-house-in-a-jerez-winery-iniesta-nowell-arquitectos-photo)

© Rafael Iniesta Nowell

[![House in a Jerez Winery / Iniesta Nowell Arquitectos - Interior Photography](https://images.adsttc.com/media/images/62f4/0a46/3838/8501/6ffb/f22d/thumb_jpg/vivienda-en-una-bodega-de-jerez-iniesta-nowell-arquitectos_18.jpg?1660160632 "© Rafael Iniesta Nowell")](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos/62f40a46383885016ffbf22d-house-in-a-jerez-winery-iniesta-nowell-arquitectos-photo)[![House in a Jerez Winery / Iniesta Nowell Arquitectos - Interior Photography, Windows, Glass](https://images.adsttc.com/media/images/62f4/0a43/3838/8501/6ffb/f22b/thumb_jpg/vivienda-en-una-bodega-de-jerez-iniesta-nowell-arquitectos_14.jpg?1660160653 "© Rafael Iniesta Nowell")](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos/62f40a43383885016ffbf22b-house-in-a-jerez-winery-iniesta-nowell-arquitectos-photo)[![House in a Jerez Winery / Iniesta Nowell Arquitectos - Interior Photography](https://images.adsttc.com/media/images/62f4/0a3e/3838/8501/6ffb/f226/thumb_jpg/vivienda-en-una-bodega-de-jerez-iniesta-nowell-arquitectos_3.jpg?1660160602 "© Rafael Iniesta Nowell")](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos/62f40a3e383885016ffbf226-house-in-a-jerez-winery-iniesta-nowell-arquitectos-photo)[![House in a Jerez Winery / Iniesta Nowell Arquitectos - Interior Photography, Column](https://images.adsttc.com/media/images/62f4/0a3d/3838/8501/6ffb/f225/thumb_jpg/vivienda-en-una-bodega-de-jerez-iniesta-nowell-arquitectos_9.jpg?1660160630 "© Rafael Iniesta Nowell")](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos/62f40a3d383885016ffbf225-house-in-a-jerez-winery-iniesta-nowell-arquitectos-photo)[![House in a Jerez Winery / Iniesta Nowell Arquitectos - More Images](https://images.adsttc.com/media/images/62f4/0a39/3838/8501/6ffb/f222/medium_jpg/vivienda-en-una-bodega-de-jerez-iniesta-nowell-arquitectos_4.jpg?1660160617)\+ 25](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos/62f40a39383885016ffbf222-house-in-a-jerez-winery-iniesta-nowell-arquitectos-photo)

-   Area Area of this architecture project Area :  [4144](https://www.archdaily.com/search/projects/min_area/308/max_area/462?ad_name=project-specs&ad_medium=single) ft²
-   Year Completion year of this architecture project Year :  [2022](https://www.archdaily.com/search/projects/year/2022?ad_name=project-specs&ad_medium=single)
-   Photographs
-   Manufacturers Brands with products used in this architecture project
-   Lead Architects : Rafael Iniesta Nowell, Luis Gutiérrez Sancho
    

More SpecsLess Specs

[![House in a Jerez Winery / Iniesta Nowell Arquitectos - Interior Photography](https://images.adsttc.com/media/images/62f4/0a46/3838/8501/6ffb/f22d/medium_jpg/vivienda-en-una-bodega-de-jerez-iniesta-nowell-arquitectos_18.jpg?1660160632)](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos/62f40a46383885016ffbf22d-house-in-a-jerez-winery-iniesta-nowell-arquitectos-photo)

© Rafael Iniesta Nowell

*Text description provided by the architects.* In the city of [Jerez de la Frontera](https://www.archdaily.com/tag/jerez-de-la-frontera), wineries sit side by side with the rest of the houses to shape the historic center, establishing a unique city skyline that is closely linked to the wine-making tradition in this part of southern Spain. The “soleras and criaderas” system allows the wine to age in barrels arranged in vertical structures inside a specific type of cellar which needs to be large, dark, ventilated, and cool. These spaces have an unforgettable aroma and are dark save for the occasional ray of light.

[![House in a Jerez Winery / Iniesta Nowell Arquitectos - Interior Photography, Windows, Glass](https://images.adsttc.com/media/images/62f4/0a43/3838/8501/6ffb/f22b/medium_jpg/vivienda-en-una-bodega-de-jerez-iniesta-nowell-arquitectos_14.jpg?1660160653)](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos/62f40a43383885016ffbf22b-house-in-a-jerez-winery-iniesta-nowell-arquitectos-photo)

© Rafael Iniesta Nowell

From the end of the 18th Century, sherry wine began to be exported worldwide and the winemakers went from operating domestically to industrially without leaving the city. As a result, this city in the south of Spain has been shaped by its connection to wine production. In addition to the cellars, a whole array of streets, squares, and extra spaces have been needed for various maintenance tasks; including cleaning and repairing barrels.

[![House in a Jerez Winery / Iniesta Nowell Arquitectos - Interior Photography, Column](https://images.adsttc.com/media/images/62f4/0a3d/3838/8501/6ffb/f225/medium_jpg/vivienda-en-una-bodega-de-jerez-iniesta-nowell-arquitectos_9.jpg?1660160630)](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos/62f40a3d383885016ffbf225-house-in-a-jerez-winery-iniesta-nowell-arquitectos-photo)

© Rafael Iniesta Nowell

Over time, many of these buildings have been repurposed for multiple uses: shops, offices, gyms, and homes. The winery in this project was previously used as a furniture warehouse and was left abandoned when we were contacted to transform it into a house.

[![House in a Jerez Winery / Iniesta Nowell Arquitectos - Interior Photography, Kitchen, Table, Windows, Beam](https://images.adsttc.com/media/images/62f4/0a38/3838/8501/6ffb/f21f/medium_jpg/vivienda-en-una-bodega-de-jerez-iniesta-nowell-arquitectos_7.jpg?1660160610)](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos/62f40a38383885016ffbf21f-house-in-a-jerez-winery-iniesta-nowell-arquitectos-photo)

© Rafael Iniesta Nowell

[![House in a Jerez Winery / Iniesta Nowell Arquitectos - Image 26 of 30](https://images.adsttc.com/media/images/62f4/0a10/3838/8501/6ffb/f217/medium_jpg/planimetria-4-4.jpg?1660160538)](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos/62f40a10383885016ffbf217-house-in-a-jerez-winery-iniesta-nowell-arquitectos-plan-ground-floor)

Plan - Ground floor

[![House in a Jerez Winery / Iniesta Nowell Arquitectos - Image 27 of 30](https://images.adsttc.com/media/images/62f4/0a0f/3838/8501/6ffb/f216/medium_jpg/planimetria-5-5.jpg?1660160549)](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos/62f40a0f383885016ffbf216-house-in-a-jerez-winery-iniesta-nowell-arquitectos-plan-1st-floor)

Plan - 1st floor

[![House in a Jerez Winery / Iniesta Nowell Arquitectos - Interior Photography, Countertop, Windows, Beam](https://images.adsttc.com/media/images/62f4/0a36/3838/8501/6ffb/f21d/medium_jpg/vivienda-en-una-bodega-de-jerez-iniesta-nowell-arquitectos_6.jpg?1660160586)](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos/62f40a36383885016ffbf21d-house-in-a-jerez-winery-iniesta-nowell-arquitectos-photo)

© Rafael Iniesta Nowell

From the available documentation, we were able to ascertain that it was a small domestic winery, possibly linked to a house that has since disappeared. The deeds mention a maintenance alleyway, but this was impossible to see in the condition it was left in.

[![House in a Jerez Winery / Iniesta Nowell Arquitectos - Interior Photography, Living Room, Windows, Table, Chair, Beam](https://images.adsttc.com/media/images/62f4/0a37/3838/8501/6ffb/f21e/medium_jpg/vivienda-en-una-bodega-de-jerez-iniesta-nowell-arquitectos_5.jpg?1660160590)](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos/62f40a37383885016ffbf21e-house-in-a-jerez-winery-iniesta-nowell-arquitectos-photo)

© Rafael Iniesta Nowell

Restoring this winery was undoubtedly an opportunity to find a part of the old city – the network of service alleys that make up the “second city” connected to the world of Jerez wine. A city within a city.

[![House in a Jerez Winery / Iniesta Nowell Arquitectos - Exterior Photography, Windows, Handrail](https://images.adsttc.com/media/images/62f4/0a44/3838/8501/6ffb/f22c/medium_jpg/vivienda-en-una-bodega-de-jerez-iniesta-nowell-arquitectos_16.jpg?1660160611)](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos/62f40a44383885016ffbf22c-house-in-a-jerez-winery-iniesta-nowell-arquitectos-photo)

© Rafael Iniesta Nowell

We started with a very compact building without ventilation, then decided to work inversely by finding the remains of the service alley and opening up a new back terrace. This is a place for getting together, as well as to cool off in the small pool.

[![House in a Jerez Winery / Iniesta Nowell Arquitectos - Interior Photography](https://images.adsttc.com/media/images/62f4/0a3e/3838/8501/6ffb/f226/medium_jpg/vivienda-en-una-bodega-de-jerez-iniesta-nowell-arquitectos_3.jpg?1660160602)](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos/62f40a3e383885016ffbf226-house-in-a-jerez-winery-iniesta-nowell-arquitectos-photo)

© Rafael Iniesta Nowell

The living room and kitchen are located on the main façade, preserving the monumental character provided by the building’s original height, while to the rear the rooms are arranged on two levels with views over the patio with the pool. There are open-plan spaces that allow for a view through the whole building, both from south to north and east to west. The project became a process of studying and adapting the pre-existing structure, where we worked with systems and materials commonly used in winery architecture: local limestone, lime, pine, and iron.

[![House in a Jerez Winery / Iniesta Nowell Arquitectos - Interior Photography, Concrete, Windows](https://images.adsttc.com/media/images/62f4/0a42/3838/8501/6ffb/f229/medium_jpg/vivienda-en-una-bodega-de-jerez-iniesta-nowell-arquitectos_21.jpg?1660160702)](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos/62f40a42383885016ffbf229-house-in-a-jerez-winery-iniesta-nowell-arquitectos-photo)

© Rafael Iniesta Nowell

Out of deep respect for the typology and building methods, we have renovated a forgotten structure into a Mediterranean, Andalucian house. At the same time, we have put part of the urban fabric of the city of wineries back into service, which continues to define Jerez today.

[![House in a Jerez Winery / Iniesta Nowell Arquitectos - Exterior Photography, Chair, Windows, Facade](https://images.adsttc.com/media/images/62f4/0a3a/3838/8501/6ffb/f223/medium_jpg/vivienda-en-una-bodega-de-jerez-iniesta-nowell-arquitectos_19.jpg?1660160628)](https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos/62f40a3a383885016ffbf223-house-in-a-jerez-winery-iniesta-nowell-arquitectos-photo)

© Rafael Iniesta Nowell

## Project gallery

See allShow less

About this office

![](https://images.adsttc.com/media/images/62f4/0a46/3838/8501/6ffb/f22d/thumb_jpg/vivienda-en-una-bodega-de-jerez-iniesta-nowell-arquitectos_18.jpg?1660160632)

Published on August 14, 2022

**Cite:** "House in a Jerez Winery / Iniesta Nowell Arquitectos" \[Vivienda en una bodega de Jerez / Iniesta Nowell Arquitectos\] 14 Aug 2022. ArchDaily. Accessed . <https://www.archdaily.com/986997/house-in-a-jerez-winery-iniesta-nowell-arquitectos> ISSN 0719-8884

## 世界上最受欢迎的建筑网站现已推出你的母语版本!

### 想浏览ArchDaily中国吗?

[是](https://www.archdaily.cn/cn?ad_name=home_cn_redirect&ad_medium=popup)否

### Did you know?

You'll now receive updates based on what you follow! Personalize your stream and start following your favorite authors, offices and users.

---