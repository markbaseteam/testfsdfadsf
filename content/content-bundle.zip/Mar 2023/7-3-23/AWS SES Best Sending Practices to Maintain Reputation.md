Tag :- [[ReadItLater]] , 
Added :- 2023-03-07

-----
# [AWS SES Best Sending Practices to Maintain Reputation](https://mailbluster.com/blog/aws-ses-best-sending-practices-to-maintain-reputation)

Amazon always checks in with your email sending practices. Your Amazon SES account uses a set of IP addresses that are shared with other users. If any of your sending practices goes against their policy, Amazon SES might pause your account’s ability to send additional emails to protect the reputation of the shared IP addresses. The content of your emails plays a major role in the maintenance of your account reputation too. Therefore, you have to be careful about maintaining your email quality; otherwise, your sending through AWS SES might come to a halt. There are two steps in the process, **account put under review** and **account put on pause**. Let’s take a look at these steps in detail.

## **AWS Account Review by Amazon**

Issues that could necessitate an account review include:

-   A bounce rate of 5% or higher
-   A complaint rate of 0.1 % or higher
-   Issues discovered during a manual investigation of the account

The manual investigation will include the quality of the content you’re sharing via emails. The language and content of your mail in specific must indicate a previously established relationship so that it never gets considered “cold calling” in nature. You can follow these simple practices while creating your email content:

##### **1**. Consistent branding:

-   **Logo**: Using a consistent logo of your business in the email header and footer.
-   **Name**: Using a consistent name of your business in everywhere of your email content.
-   **URL**: Using a consistent URL of your business in everywhere of your email content.

##### 2\. High-quality email content:

-   Your email should look appealing to the recipient. 
-   No more than 40% image coverage and a minimum of 60% text
-   Make your emails in a way where they make sense when you take the images out: The Golden Rule is “an email should deliver its message effectively, with or without images”
-   Use images with purpose. Don’t just throw in a random stock photo for the sake of more content.
-   Use Alt text with images
-   Each email should contain the postal/physical address the business
-   Each email should contain why a recipient is receiving your email. This should be easy to find.
-   Each email should contain how to unsubscribe from your emails with an unsubscription link. This should be easy to find.
-   It is appreciable to add a contact number, contact email, social media URLs of your business
-   Copyright of your business if it applies

##### 3\. Maintaining a good sending reputation:

-   Using zero bounce or similar services to validate your lead email addresses prior to sending emails to them.
-   Remove permanently bounced emails or emails that complained against your emails from your sending list.
-   Send emails to only those who have interacted with your business/email within the last six months.

If your AWS account is put under the review stage, Amazon will send you a warning email shortly and ask for an explanation. If you fail to respond within the review period or cannot satisfy them with your answers regarding the issue, it is likely that your AWS account sending capability will be paused.

## **AWS Account Sending Capability Paused by Amazon**

Some of the issues that could cause a sending pause are as follows:

1.  The Amazon SES account had already been placed under review, and the problem had not been resolved by the end of the review period.
2.  A bounce rate of 10%or higher
3.  A complaint rate of at least 0.5 %
4.  The account was reviewed several times for the same problem.
5.  Emails sent from the account were in violation of the AWS Service Terms.

In this situation, you won’t be able to send any emails using this account. Amazon provides some guidelines to resolve this, you can find the details [here](https://aws.amazon.com/premiumsupport/knowledge-center/ses-resolve-account-review-pause/).

## **AmazonSES Rejection Case Study and What to Do About It**

In this section, we’ll compare two emails.   
**Sample Campaign 1  
**This campaign caused the review of the AWS account and lead to a pause in sending capability.

![](https://mailbluster.com/blog/wp-content/uploads/2021/07/pasted-image-0.png)

  
These are the issues with this email content:

-   Email doesn’t contain why the client is receiving the email
-   No business postal address
-   No phone/contact number/email
-   No social media
-   Does not have High-quality email content

**Sample Campaign 2** This is an example of email content prepared with the best practices following the AWS Acceptable Use Policy.

![](https://mailbluster.com/blog/wp-content/uploads/2021/07/pasted-image-0-1.png)

You can direct to the [AWS blog](https://aws.amazon.com/blogs/messaging-and-targeting/amazon-ses-best-practices-top-5-best-practices-for-list-management/) page for a more detailed understanding of the best sending practices needed for your AWS SES reputation.

Got any queries about email sending practices? Reach out to us via [email](https://mailbluster.com/cdn-cgi/l/email-protection#d0b8b5bcbcbf90bdb1b9bcb2bca5a3a4b5a2feb3bfbd) or give us a knock on the live chat at mailbluster.com.  
Happy Sending! 💙