Tag :- [[ReadItLater]] , 
Added :- 2023-03-07

-----
# [How Using ‘Add To Cart’ Optimisation In Facebook Ads Can Help To Drive A Better ROAS - Coast Digital](https://www.coastdigital.co.uk/2022/04/01/how-using-add-to-cart-optimisation-in-facebook-ads-can-help-to-drive-a-better-roas/)

[![Lucy Henning](https://www.coastdigital.co.uk/wp-content/uploads/2018/09/Lucy-150x150.jpg)](https://www.coastdigital.co.uk/2022/04/01/how-using-add-to-cart-optimisation-in-facebook-ads-can-help-to-drive-a-better-roas/)

When setting up e-commerce conversion campaigns on Facebook, most marketers would typically choose to optimise towards the end goal – the purchase event.

They often focus their efforts on optimising within the audience targeting, so looking at interest audiences, custom audiences, and lookalikes. Therefore the conversion and delivery optimisation are not given as much thought.

## **How delivery optimisation can improve the results of your ads**

Facebook ads delivery optimisation is used to help Facebook understand your ad campaign’s goals. Basically, you’re telling Facebook’s algorithms what your anticipated results are and who should see your ads.

Facebook only shows your ads to a fraction of your target audience, and the optimisation settings play a big part in telling Facebook which users should see your ads.

When you select a Conversion Event to optimise for, Facebook will show your ads to people in your audience who are likely to complete that specific conversion action. Facebook builds more data as your conversion event fires, so in short, **conversions with more events firing has more data on your audience.**

If you take a basic user funnel, there are many touchpoints before a user purchases. They initially begin by entering the site, so a page view event. They then view products and ‘add to cart’, so another two touchpoints have been actioned there. Then before purchasing they initiate the checkout before finally triggering the purchase conversion event.

The benchmark for Facebook being able to optimise most efficiently is 50 conversions per week. For example, an e-commerce store is getting 15 sales per week, there will be a considerably higher volume of ‘add to carts’ vs purchases for Facebook to optimise toward (if you use an average cart completion rate).

So, it makes sense for sites getting similar event volumes to use one or even two steps pre-purchase to make sure Facebook is using data to optimise.

## **The results speak for themselves…**

We also put this theory to the test with a large retail client whose ad spend is within excess of £250k per month. This ad account registers over 10,000 purchase event fires a day on average.

They found that whilst most of their product sets drove a positive Return On Ad Spend (ROAS), they couldn’t seem to crack their beauty offering.

We switched the beauty ad sets over to ‘add to cart’ optimisation, and within a day ROAS had skyrocketed from 1.01 to 5.15!

This showed us that this technique is not only effective for Facebook advertisers that don’t have enough volume on their event data, but also drives positive results for advertisers that have huge event data within their pixel.

Meaning that in general, using an event with more fires as an optimisation goal in Facebook will help Facebook pixel optimise smarter and faster, even when it is not the end goal.

We are still testing this theory for even smaller Facebook advertisers, using steps earlier and earlier in the funnel to ensure we are giving Facebook enough data to use when searching for users to share our ads to.

**To start improving your ROAS for your paid social media advertising, [speak to our friendly team of experts today](https://www.coastdigital.co.uk/contact/).**

## More on this subject

[![Amy Mullin](https://www.coastdigital.co.uk/wp-content/uploads/2022/03/Image-1-220x220.jpg)](https://www.coastdigital.co.uk/author/amy-mullin/)

### [The Power of TikTok Ads](https://www.coastdigital.co.uk/2022/04/07/the-power-of-tiktok-ads/)

A blog offering an introduction to TikTok, sharing what makes this social network so unique, the ad types that are available and some top tips for seeing success on the platform.

[![Brad King](https://www.coastdigital.co.uk/wp-content/uploads/2021/09/Brad2-220x220.jpg)](https://www.coastdigital.co.uk/author/bking/)

### [We’re Finalists at the 2022 UK Paid Media Awards!](https://www.coastdigital.co.uk/2022/03/25/were-finalists-at-the-2022-uk-paid-media-awards/)

We are delighted to share that we have been selected as finalists for the Paid Social Campaign of the Year at the 2022 UK Paid Media Awards for our Debehams.com Womenswear Winter Campaign.

[Back to the blog](https://www.coastdigital.co.uk/blog/)