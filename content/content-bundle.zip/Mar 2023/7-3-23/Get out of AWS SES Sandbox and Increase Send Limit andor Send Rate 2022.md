Tag :- [[ReadItLater]] , 
Added :- 2023-03-07

-----
# [Get out of AWS SES Sandbox and Increase Send Limit and/or Send Rate 2022](https://mailbluster.com/blog/get-out-of-aws-ses-sandbox-and-increase-send-limit-and-or-send-rate-2022)

2022 is knocking at the door and you need a fresh new strategy for your email marketing skills this new year.  
Are you a beginner at email marketing who is about to start using MailBluster and AWS SES? Skip the next paragraph and direct to the main part [here](https://mailbluster.com/blog/get-out-of-aws-ses-sandbox-and-increase-send-limit-and-or-send-rate-2022#Let%E2%80%99s-get-started).

If you’re already using MailBluster, the most promising cost-effective email marketing platform ever, you almost certainly have an AWS SES setup linked to MailBluster. And, guess what, the most difficult part of this process is getting your AWS SES out of Sandbox and increasing the send limit. Yes, we have a [guide/blog](https://mailbluster.com/blog/how-to-increase-aws-sending-limits/) and a [video tutorial](https://youtu.be/6mU46yOwjhs) that explain this difficult process in detail, and these were previously adequate.  
For the following two reasons, the guides are no longer very effective:  
*1\. Amazon Web Services has updated their UI to a level seeing which our users might get confused to align with our guide.*  
*2\. Users and potential customers have left feedback saying they want more details on this.*

So here we are, with a brand new updated and detailed guide on how to **Get out of AWS SES Sandbox and Increase Send Limit and/or Send Rate 2022.**  
In this article, we will walk you through the steps of **requesting Amazon to get you out of the Sandbox, enable sending and increase the sending limit** of your AWS SES account.

Before getting started, sign in to your [AWS Console.](https://us-west-2.console.aws.amazon.com/console/home?)  
If you don’t have an AWS account yet, please visit [Signing up free for AWS.](https://docs.aws.amazon.com/ses/latest/DeveloperGuide/sign-up-for-aws.html)

## **Let’s get started**  

1 In the AWS Management Console, click on **Amazon Simple Email Service**.

![](https://mailbluster.com/blog/wp-content/uploads/2021/12/000.png)

  

2 Now select **Account dashboard** from the left menu.

![](https://mailbluster.com/blog/wp-content/uploads/2022/06/2.jpg)

3 You can see your account is in sandbox mode in the SES region US East (Ohio). Click on **Request production access**.

![](https://mailbluster.com/blog/wp-content/uploads/2021/12/3.jpg)

  

4 To Request for production access, select the details. For example what type of emails you want to send, marketing or transactional, your website url.

![](https://mailbluster.com/blog/wp-content/uploads/2021/12/4.jpg)

  

5 Now write a brief case description, for example **We will email our registered users and those who have subscribed to our messages on a monthly and weekly basis with updates and special offers**.

![](https://mailbluster.com/blog/wp-content/uploads/2021/12/5.jpg)

  

6 You may add additional contact information. Check the box to agree to AWS terms and policy and **Submit request**.

![](https://mailbluster.com/blog/wp-content/uploads/2021/12/6.jpg)

  

7 You will see a highlighted notification if your case request is submitted successfully.

![](https://mailbluster.com/blog/wp-content/uploads/2021/12/7-1.jpg)

8 AWS might take up to 72 hours to respond to your case request. To check for new responses from Amazon, go to the AWS Management Console and select **Support**.

![](https://mailbluster.com/blog/wp-content/uploads/2021/12/8.jpg)

  

9 Select and click on your case **SES Production Access**.

![](https://mailbluster.com/blog/wp-content/uploads/2021/12/9.jpg)

  

10 Amazon **case reply 01**.

![](https://mailbluster.com/blog/wp-content/uploads/2021/12/10.jpg)

  
*Hello,*  
*Thank you for submitting your request to increase your sending limits. We are unable to grant your request at this time because we do not have enough information about your use case.*

*If you can provide additional information about how you plan to use Amazon SES, we may be able to grant your request. In your response, include as much detail as you can about your email-sending processes and procedures.*

*For example, tell us how often you send email, how you maintain your recipient lists, and how you manage bounces,* complaints, and unsubscribe requests. It is also helpful to provide examples of the email you plan to send so we can ensure that you are sending high-quality content.

You can provide this information by replying to the correspondence, in the console link below. Our team provides an initial response to your request within 24 hours. If we’re able to do so, we’ll grant your request within this 24-hour period. However, if we need to obtain additional information from you, it might take longer to resolve your request.

*Thank you for contacting Amazon Web Services.*

11 **Response** to Amazons case reply 01.

![](https://mailbluster.com/blog/wp-content/uploads/2021/12/11-1.jpg)

  
*Hello Team AWS,*  
*We appreciate you taking the time to review my request for production access. Only registered users will receive emails from us. Our website’s address is https://dreamwayhl.com/ .*

*We currently have 15,000 registered users. All email addresses have been validated. These emails were obtained through Facebook lead marketing. We intend to provide weekly and monthly updates on available real estate opportunities. You can look at our social media platforms, where all these client email IDs were collected with their permission and double-verified via phone calls.* 

*Facebook: https://www.facebook.com/dreamwayholdingsltd*    
*Instagram: www.instagram.com/dreamwayholdingsltd*  
*LinkedIn: www.linkedin.com/company/dreamwayhl*  
*https://www.youtube.com/channel/UCugLs9YKyMEe4WvWZ454mzA*  

*In accordance with the AWS documentation, we will use a program called MailBluster(https://mailbluster.com/ ) to manage bounces, complaints, and unsubscriptions.*  
*In the event of a permanent bounce, MailBluster unsubscribes the lead immediately. There will be no further emails sent to that address. If the bounce is temporary, MailBluster saves the bounce response (along with the timestamp, type, and subtype) for future reference.*  
*In response to complaints, MailBluster immediately unsubscribes the email address. There will be no further emails sent to that address.*  
*MailBluster will also help us create email campaigns with the required content and format (as advised by AWS) to help us maintain a good email sending reputation.*  
*Additionally, prior to campaign launch, we will use MailBluster’s auto-bounce checking feature to identify and remove potential bounces. This Amazon SES account already has two verified email addresses, and the DNS records for the domain https://dreamwayhl.com/  are set up correctly.*

*Finally, if you require any additional information in order to grant us production access, please do not hesitate to contact me.*  
*Best,*  
*Saima Shetu*  
*Marketing & Sales*  
*Dreamway Holdings Ltd.*

12 Amazon **case reply 02**.

![](https://mailbluster.com/blog/wp-content/uploads/2021/12/12.jpg)

  
Hello,  
Thank you for submitting your request to increase your sending limits. We are unable to grant your request at this time.

We reviewed your request and determined that your use of Amazon SES could have a negative impact on our service. We are denying this request to prevent other Amazon SES customers from experiencing interruptions in service.

For security purposes, we are unable to provide specific details.

If you can provide additional information about how you plan to use Amazon SES, we might be able to grant your request. You can provide this information by replying to this message. In your response, include as much detail as you can about your email-sending processes and procedures.

For example, tell us how often you send email, how you maintain your recipient lists, and how you manage bounces, complaints, and unsubscribe requests. It is also helpful to provide examples of the email you plan to send so we can ensure that you are sending high-quality content.

For more information about our policies, please review the AWS Acceptable Use Policy (http://aws.amazon.com/aup/ ) and AWS Service Terms ( http://aws.amazon.com/serviceterms/).

Thank you for contacting Amazon Web Services.

13 **Response** to Amazons case reply 02.

![](https://mailbluster.com/blog/wp-content/uploads/2021/12/13-1.jpg)

  
Hello, AWS team!  
Thank you for taking the time to read through our response to the case request.

\>We reviewed your request and determined that your use of Amazon SES could have a negative impact on our service. On this point, we must respectfully disagree with you. We’ve been in the real estate business for more than two years. We have legal customers who were double-verified via phone calls. You can look at our social media platforms, where the majority of these client email IDs were collected with their permission. Facebook: https://www.facebook.com/dreamwayholdingsltd

Instagram: www.instagram.com/dreamwayholdingsltd LinkedIn: www.linkedin.com/company/dreamwayhl https://www.youtube.com/channel/UCugLs9YKyMEe4WvWZ454mzA

We will send weekly and monthly offers to our legal clients. We check and update our email list on a regular basis, so no email on the list is more than 6 months old.  
Dreamway Holdings has begun working with MailBluster (https://mailbluster.com/), an email marketing platform that will manage and control the following- 1. Handling of bounces and complaints 2. Clean the list every time before sending a campaign to eliminate any potential bounces or invalid leads. 3. The email content will include all of the information recommended by AWS SES, such as why a subscriber is receiving our email, a visible unsubscribe option, and detailed Dreamway Holding Ltd addresses (website, social media, physical address etc).

Please review our request again, and we hope you’ll find Dreamway Holdings Ltd to be a potential healthy and reputable AWS SES client.

Please let me know if there is anything else I can do to help you grant us production access.  
Best,  
Saima Shetu Marketing & Sales.  
Dreamway Holdings Ltd.

14 Amazon **case reply 03**.

![](https://mailbluster.com/blog/wp-content/uploads/2021/12/14.jpg)

  
Hello,

Thank you for providing us with additional information about your Amazon SES account in the US East (Ohio) region.  
We reviewed this information, but we are still unable to grant your request. We made this decision because we believe that your use case would impact the deliverability of our service.

We cannot assist you further with this issue, and we will not respond to additional messages on this subject.

We value your feedback. Please share your experience by rating this correspondence using the AWS Support Center link at the end of this correspondence. Each correspondence can also be rated by selecting the stars in top right corner of each correspondence within the AWS Support Center.

Best regards,  
Trust and Safety  
Amazon Web Services

15 **Response** to Amazons case reply 03.

![](https://mailbluster.com/blog/wp-content/uploads/2021/12/15.jpg)

  
Good day!  
Thanks for reviewing our case.

\>We made this decision because we believe that your use case would impact the deliverability of our service.  
We must respectfully disagree with you on this point. We’ve been in the real estate industry for over two years. We have legal clients who have been double-verified via phone calls. You can see the majority of these client email IDs on our social media platforms, where they were collected with their permission.

Please review the additional information you asked for again:  
1\. We send emails about 2-3 times a month.  
2\. We maintain the list by adding subscriptions from our new clients and removing the bounces and unsubscribes after every single campaign we sent.  
3\. We will use a program called MailBluster([https://mailbluster.com/)](https://mailbluster.com/) to manage bounces, complaints, and unsubscriptions. In the event of a permanent bounce, MailBluster unsubscribes the lead immediately. There will be no further emails sent to that address. If the bounce is temporary, MailBluster saves the bounce response (along with the timestamp, type, and subtype) for future reference. In response to complaints, MailBluster immediately unsubscribes the email address. There will be no further emails sent to that address.  
4\. MailBluster will also help us create email campaigns with the required content and format (as advised by AWS) to help us maintain a good email sending reputation.  
5\. Additionally, prior to campaign launch, we will use MailBluster’s auto-bounce checking feature to identify and remove potential bounces.

Also attached is a sample of the emails we want to send to our clients.

![](https://mailbluster.com/blog/wp-content/uploads/2021/12/15-1.jpg)

If you require any additional information in order to grant us production access, please do not hesitate to contact me.  
Best,  
Saima Shetu  
Marketing & Sales  
Dreamway Holdings Ltd.  

16 Amazon **case reply 04**.

![](https://mailbluster.com/blog/wp-content/uploads/2021/12/16-1.jpg)

  
Hello, My name is Ajith and your case has been escalated to me for Senior Level Review. Thank you for your patience while we reviewed your case. We have increased the sending limits. Your new sending quota is 50,000 messages per day. Your maximum send rate is now 14 messages per second. We have also moved your account out of the Amazon SES sandbox. This takes effect immediately in the US East (Ohio) region. You can view the current sending rate and sending quota for your account on the Sending Statistics page of the Amazon SES console, or by using the GetSendQuota API. As you get started with Amazon SES, keep in mind that you must:  
– Comply with the AWS Acceptable Use Policy ([http://aws.amazon.com/aup/](http://aws.amazon.com/aup/)) and read the Amazon SES Service Terms (section Amazon Simple Email Service (SES) of [http://aws.amazon.com/service-terms/](http://aws.amazon.com/service-terms/)).

– Send only high-quality emails to recipients who expect to hear from you. For more information, see [https://docs.aws.amazon.com/ses/latest/DeveloperGuide/tips-and-best-practices.html](https://docs.aws.amazon.com/ses/latest/DeveloperGuide/tips-and-best-practices.html)– Set up a process to handle bounces and complaints. For more information, see [http://docs.aws.amazon.com/ses/latest/DeveloperGuide/bounce-complaint-notifications.html  
](http://docs.aws.amazon.com/ses/latest/DeveloperGuide/bounce-complaint-notifications.html)  
– Use your new account to send a different type of email than you are sending from your other account(s), if applicable. For more information, see [http://docs.aws.amazon.com/ses/latest/DeveloperGuide/multiple-accounts.html](http://docs.aws.amazon.com/ses/latest/DeveloperGuide/multiple-accounts.html)– Use the Amazon SES mailbox simulator to test your system so that your testing does not adversely impact your account. For more information, see [http://docs.aws.amazon.com/ses/latest/DeveloperGuide/mailbox-simulator.html](http://docs.aws.amazon.com/ses/latest/DeveloperGuide/mailbox-simulator.html)– Apply for higher sending limits before you need them. For more information, see [http://docs.aws.amazon.com/ses/latest/DeveloperGuide/manage-sending-limits.html](http://docs.aws.amazon.com/ses/latest/DeveloperGuide/manage-sending-limits.html)– With Amazon SES, you pay only for what you use. There are no contract negotiations and no minimum charges. For more information see: [https://aws.amazon.com/ses/pricing/](https://aws.amazon.com/ses/pricing/) Thank you for using Amazon Web Services.

  
Finally, Amazon was convinced after several iterations and moved the account from Sandbox to Production with an increased daily send limit and send rate.   
The primary trick here is to convince Amazon that your business is legitimate and that you have authentic subscribers who have given you permission to send them emails. (The critical point here is to NOT lie and mislead Amazon about your business.)

What are you waiting for then?  
Go get your SES limit increased and blast your newsletter with MailBluster.

Got any queries or suggestions? Let us know in the comments below, or [contact](https://mailbluster.com/contact) us anytime.

**Happy Sending!** 💙