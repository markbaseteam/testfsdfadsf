Tag :- [[ReadItLater]] , 
Added :- 2023-03-03

-----
What are some of the best life tips?

[








](https://infoorb.quora.com/What-are-some-of-the-best-life-tips)

1.  Don't get addicted to porn, smoking, alcohol, internet or sex.
2.  Do not hide anything from your doctor, he is not your father, he will not scold you.
3.  Sex lasts on average 20 minutes, do not ruin your life because of this.
4.  Smile frequently, 30 seconds every 30 minutes, this will increase your productivity and mental energy.
5.  Don't fall into debt. Pay all your bills early before they become a headache.
6.  Give thanks for the food you were given at someone else's house.
7.  Never wait for the perfect moment to do something, do what's on your mind right now and learn how to do it better as time goes on.
8.  Make your bed as soon as you get up.
9.  Throw away the things you no longer use, or even better, donate them. Also start getting rid of all the clothes you haven't worn in the last 3 months.
10.  Find a hobby that you like too much.
11.  Have a list of all the good things about you, read it daily when you wake up.
12.  Exercise at least 30 minutes after getting up in the morning.
13.  Do not sit in one position for more than 1 hour doing a task, get up and distract yourself for about 5 minutes.
14.  Stop using your cell phone for so long!!
15.  Your mental health is more important than anything else. Prioritize yourself.
16.  Never give up on your dreams. Learn to finish everything you started and one day you will see the results.
17.  Learn to remove all toxic, fake people and purposeless relationships from your life.
18.  Enjoy the achievements you have obtained so far in your life.
19.  Listen to music and dance
20.  Never expect the approval of other people, what matters is how you feel.
21.  Work hard and discover the world, you never know what awaits you tomorrow.
22.  Don't spend your hard-earned money on expensive things.
23.  Improve your communication skills, they are quite useful.
24.  What goes around comes around, karma is real.