Tag :- [[ReadItLater]] , 
Added :- 2023-03-03

-----
# [How to turn an open source project into a profitable business](https://techcrunch.com/2023/03/02/how-to-turn-an-open-source-project-into-a-profitable-business/)

Alongside fellow [Evil Martians](https://evilmartians.com/), Victoria Melnikova builds devtools and commercial open source products and writes about her journey in tech.

Despite the premise of open source software distribution being “free,” multibillion dollar companies like RedHat, MongoDB, GitLab and Elastic have already broken ground building profitable businesses with open source at their core.

But is it possible for a smaller open source project to find its way into this land of commercial opportunity?

## COSS is accelerating

In general, the trends in commercial open source (COSS) are encouraging. New products like Meilisearch and Supabase are gaining traction exponentially faster than the legends of COSS like MongoDB, which were founded much earlier.

Let’s give some more context to the graph above. From 2010 to today, the number of GitHub users has exploded from 500,000 to 103 million. It might be tempting to suggest that this influx of new users into the community would be the driving force behind the increase in stars.

> Your open source project can begin as a pet project but only if you can devote time to it.

But, at the same time, the number of projects (repositories) has grown at an even higher rate: from 600,000 to 359 million. And investments in open source products have almost tripled from 58 deals in 2015 to 144 deals in 2021.

Importantly, the average number of users per repository has shrunk from 0.8 to 0.3. This means the competition for GitHub stars is now higher than ever, which suggests the superstars above are indeed outliers and it’ll be difficult to replicate their success.

Judging from these numbers, investments and star dynamics, COSS is in a sweet spot at the moment.

That said, we must keep in mind that COSS and developer tools still only occupy a niche. After all, there are only 25 million to 30 million software developers in the world. Even though productivity in this industry is much higher than in many others, this number is only a fraction of other big markets like finance or retail.

Moreover, monetizing products built for developers is still, to a certain extent, an open question.

## How to monetize open source

There are multiple strategies for earning money from open source.

Let’s start with a simple one: crowdfunding and donations. Grant money falls into the same category as donations, as the only difference is in how you raise the money. Foundations are a vehicle for collecting donations from large sponsors or from a great number of sponsors.

Sadly, such earnings are unlikely to cover the costs of a growing COSS. Take PostCSS, a widely popular CSS framework built by Andrey Sitnik. Through an Open Collective hub, with 27,000 stars on GitHub, he collects only about $12,000 per year despite the fact that massive companies like Meta or Google use PostCSS and could potentially support the product.