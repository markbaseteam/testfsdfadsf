[[ReadItLater]] [[Article]]

# [Our CEO's interview with Tekpon](https://omnisearch.ai/blog/our-ceos-interview-with-tekpon)

Our co-founder and CEO Marin Smiljanic had the pleasure of appearing on the [Tekpon](https://tekpon.com/) podcast last week, and talked to host Cristian Dina about a ton of different startup-related topics, from deciding to form a team a technical co-founder, to pricing challenges and hiring. We also talk about our differentiation and discuss our favorite software. Check out the full interview [here](https://tekpon.com/insights/transcribe-process-and-search-your-audio-and-video-content-marin-smiljanic-omnisearch/).

‍

![](ReadItLater%20Inbox/assets/6382edcb38bb0d3190dfdc6e_tekpon.jpg..jpg)

For those unfamiliar with the company, Tekpon is a software aggregator born out of a genuine desire to help people change the way they consume and purchase software products and services. Tekpon is built by a team of tech enthusiasts, but most of all, their main goal is to help users boost their lives and businesses with the right software.

We're delighted to be featured there, and check out our [profile](https://tekpon.com/software/omnisearch/reviews/).