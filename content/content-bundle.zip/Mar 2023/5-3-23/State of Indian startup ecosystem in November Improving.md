[[ReadItLater]] [[Article]]

# [State of Indian startup ecosystem in November: Improving](https://yourstory.com/2022/12/funding-report-state-indian-startup-ecosystem-november-improving)

Testing times for the Indian startup ecosystem are far from over at the end of eleven months of 2022. *YourStory Research* data shows that in November, startups raised close to $1.4 billion.

Compared with $1.18 billion in October, this is an 18.1% month-on-month (MoM) increase. While this growth is way below October’s 30.8% MoM growth over September, there is some good news.

Both early-stage and growth-stage funding increased by 65.8% and 196.7%, compared to October when the respective stages saw monthly declines of 10.2% and 65.2%.

![Monthly funding deal flow in 2022](https://images.yourstory.com/cs/2/3834ef70ca8011eba0afddaa6974ca30/FundingreportNOV221-1669868296018.png?fm=png&auto=format&w=800)

It is noteworthy that while October turned out to record the third highest monthly growth following 66.1% and 41.7% MoM growth in August and June, the number of deals in October was just 91—[the lowest during 2022](https://yourstory.com/2022/11/funding-report-state-indian-startup-ecosystem-october-leveraged)—which was, in turn, 33.6% lower than 137 deals in September.

According to *YourStory Research*, November’s total deal count registered a 46.2% MoM improvement over October, and the monthly percentage growth of deal count is also the highest during the eleven months of 2022.

While it may be too early to claim that the startup funding scenario is in recovery mode, the 67.7% MoM decline in debt financing, worth $115.8 million in November, compared to $358.3 million in October—not just the highest during 2022, but also 8,639% more than September—does bring some respite as the ecosystem is moving away from leverage.

Following the [gloomy July](https://yourstory.com/2022/08/report-state-of-startup-ecosystem-july-gloomy), [stretched August](https://yourstory.com/2022/09/funding-report-startup-ecosystem-august-stretched), and leveraged October when debt financing accounted for 30.3% of the monthly total funding worth $1.18 billion, November saw that share decline to 8.3%.

![Stage-wise funding breakup in 2022](https://images.yourstory.com/cs/2/3834ef70ca8011eba0afddaa6974ca30/FundingreportNOV224-1669868869293.png?fm=png&auto=format&w=800)

On the other hand, the share of early-stage and growth-stage deals saw respective improvement from 18.3% and 17% in October, to 25.6% and 42.8% in November. However, the share of late-stage deals declined from October’s 34.4% to 23.2% in November.

In value terms, at $358.3 million and $598.8 million, early and growth stages saw respective MoM increases of 65.8%and 196.7% compared to October’s $216.1 million and $201.8 million, while late-stage deals worth $324.7 saw 20.3% decline compared to $407.6 in October. It is noteworthy that the MoM increase in early-stage and late-stage funding value was highest across 2022.

The impressive value growth in the early and growth stages got mirrored in the deal count too, which grew by 37.5% and 128.6% from 72 and 7 each in October, to 99 and 16 in November. Like value, the MoM volume growth in November is also the highest across 2022.

When seen through the lens of round types, in contrast to the decline of debt financing in overall funding the value of undisclosed deals accounted for 50.9% of the fund raising in November in comparison to 38.4% in October.

However, in the early stages, the share of Pre-Series A and Series A deals, worth $101 million and $168.5 million, stood at 7.2% and 12.1%, respectively, which was better than the respective $71.7 million (6.1% of the total) and $104.8 million (8.9%) in October.

![Round-wise funding breakup in 2022](https://images.yourstory.com/cs/2/3834ef70ca8011eba0afddaa6974ca30/FundingreportNOV225-1669868895721.png?fm=png&auto=format&w=800)

Similarly, funding raised across Series B ($150 million: 10.7% of the total) and Series D ($70 million: 5%) was far better than the $39.7 million (3.4%) raised in Series B deals and no funds raised in Series D during October.

On an MoM basis, funding in Series B was 277.8% higher than in October while the monthly deal value of Pre-Series A was 40.9% higher. In terms of deal volume, the 68 deals in Pre-Series A and 7 deals in Series B were respectively higher by 38.8% and 250% compared to October’s 49 deals and 2 deals in the respective series.

For both the series, the monthly volume growth seen in November is the highest.

At a time when funding winter remains a worrying factor for the startup ecosystem, the attribution of ‘improving’ as the state of the ecosystem in November may seem premature. However, the 68 deals in Pre-Series A in November marked a 38.8% increase from 49 deals during October—the lowest monthly volume for the series during 2022—which coincidentally saw a 38.8% fall over 80 deals during September.

In terms of the top sectors, coworking saw a single funding deal worth $300 million during November, and accounted for 21.5% of the month’s total funding. The coworking sector was joined by software-as-a-service (SaaS), healthtech and healthcare services, D2C, and ecommerce, with respective funding of $246.5 million (18 deals), $226.6 million (13 deals), $84.5 million (13 deals), and $76.2 million (7 deals). Together, the top five sectors accounted for 66.8% of the total funding raised during November.

![Top 20 sectors by highest funding value in November](https://images.yourstory.com/cs/2/3834ef70ca8011eba0afddaa6974ca30/FundingreportNOV222-1669868504515.png?fm=png&auto=format&w=800)

It is noteworthy that fintech and financial services and edtech and educational services—the sectors which made maximum funding-related headlines during 2021—continue to be among the top 10 funded sectors in November.

While fintech saw 13 deals worth $68.3 million, edtech had six deals worth $59.9 million in November. The top 10 sectors, which also included Cleantech, HRtech, and electric vehicles (EVs) together accounted for 88.8% of November’s total fundraising.

When seen through the lens of startups from 19 cities, which got funding in November, the top 10 accounted for 99.3% of the month’s total funding, while the top 5 accounted for 93.1% of the value.

![Top 10 cities by highest funding value in November](https://images.yourstory.com/cs/2/3834ef70ca8011eba0afddaa6974ca30/FundingreportNOV223-1669868544931.png?fm=png&auto=format&w=800)

Bengaluru topped the cities’ league table with 41.6% of the total funding raised in November as the country’s startup capital saw 39 deals worth $581.9 million. Bengaluru was followed by Delhi-NCR with 40 deals worth $420.8 million. However, funding raised by Delhi-NCR-based startups was 27.7% lower compared to that raised by Bengaluru-based startups.

Accounting for a 10.6% share of the month’s total funding, Mumbai-based startups raised $148.5 million over 20 deals in November. In comparison to the funding value of Bengaluru and Delhi-NCR-based startups during November, funding raised by Mumbai-based startups was lower by 74.5% and 64.7%, respectively.

It is somewhat encouraging to see single deals ranging between $6.2 million and $1 million in smaller cities like Bhubaneswar, Bhopal, Amritsar, Coimbatore, Kochi, and Surat.

*(Infographics by Chetan Singh)*