
 --- 
[action required](action-required.md),   
   
What's the one thing Bill Gates, my uncle Tom, and the Canada Pension Plan have in common?   
They invest in farmland. Farmland has outperformed almost all asset classes since 1991. Finite supply, growing demand, and low correlation to the stock market make it one of the best investments out there. So, why isn't everyone investing in farmland? Because farmland isn't liquid at all.   
This is why we built LandEx. LandEx is a crowdfunding investment platform enabling every European to conveniently invest in farmland from as little as €10. With low volatility and an average yearly return of 12%, farmland helps investors like my uncle Tom diversify their portfolios while maintaining growth even in a recession.   
Sign up on [LandEx](https://click.convertkit-mail.com/d0u499zw8lu0h443nr5fm/vqh3hmun7vq3entg/aHR0cHM6Ly9sYW5kZXguYWkv) today with the code TABLE and get €10 of investment credit.   
