[[ReadItLater]] [[Article]]

# [RBI’s digital lending rules: there could be more to follow](https://yourstory.com/2022/12/rbis-digital-lending-rules-there-could-be-more-to-follow)

The Reserve Bank of India’s (RBI) guidelines around digital lending, which kicked in earlier this week, have upended the fintech sector, forcing those dealing with credit to re-evaluate, or even materially alter their operations, to be in compliance with the law of the land.

Whether the digital lending framework was good or bad for the industry and fintech innovation, in general, is open to conjecture, but that the guidelines were formulated keeping the end-consumer in mind is a unanimous opinion in the industry.

To quickly recap, in August this year, the RBI’s Working Group on Digital Lending—a body constituted in January 2021 to study issues related to online lending—released a set of guidelines that promulgated greater transparency and disclosures to borrowers in the process of signing a loan.

The notification focused on three main things—regulating the entire lending chain; providing transparency to borrowers; and defining good data privacy practices.

The Central bank also condemned and put a stop to bad practices such as harassing borrowers and their friends and family for recovering loans. 

> And it seems like the RBI is not going to hang up its hat just based on the first set of regulations. A highly placed source familiar with the RBI’s thinking told *YourStory* there could be more coming from the Central bank on the underwriting front, mainly to regulate the way some Buy Now, Pay Later (BNPL) startups currently issue loans.

Not everyone is happy with the changes.

While they do bode well for the quintessential Indian borrower, the digital lending guidelines were somewhat of a dampener for the startup ecosystem, which had been innovating and experimenting with credit to make it more accessible in a country traditionally not attuned to borrowing from formal sources.

Companies like ﻿Uni Cards﻿, ﻿Slice﻿, PostPe—all of which were extending loans via cards, had to abandon their 1/3rd pay-later business models and pivot to an essentially credit card-like format. Uni Cards has plans to launch a co-branded card with SBM Bank called ‘NX Wave’. PostPe and Slice have already rolled out these on their platforms.

![Digital Lending guidelines](https://images.yourstory.com/cs/2/f49f80307d7911eaa66f3b309d9a28f5/Imageqmko-1669984797651.jpg?fm=png&auto=format&w=800)

(Design credit: Nihar Apte)

The value proposition of these companies is their rewards system, where each is trying to outdo the other on cashbacks, discounts, and exclusive deals, in a bid to capture more users.

But with intense competition from credit card companies that already offer lucrative deals, as well as established players in the ecosystem such as ﻿OneCard﻿, for example, that have already amassed users, proving their value might be harder.

“It’s a good thing that the consumer wins at the end of the day \[with so many cashbacks/rewards/discounts\], but Slice, Uni, and PostPe will have to fight it out even harder than before. We can only hope the competition doesn’t come at the expense of the millions of dollars of VC money that has been pumped into these startups,” said a well-known investor who did not want to be quoted on the record.

For other BNPL players such as ﻿LazyPay﻿, ﻿Simpl﻿, ﻿Flexmoney﻿, and ﻿ZestMoney﻿, there has been no material change in operations, except in terms of customer communication, where they’ve had to clarify that they’re a credit product, and not something similar to paying back your neighbourhood grocer at a later date.

LazyPay’s website, for example, now says “LazyPay is India's best personal loan and pay later option”, while ZestMoney’s website says, “Personalized credit limit of up to 2 lac”.

> “There has been some short-term pain since some businesses had to allocate bandwidth away from other business problems to specifically work on compliance, but for most of the industry, it hasn’t been very life-altering,” says Kunal Varma, CEO and Co-founder of credit-focussed neobank Freo.

But despite the attention diversion, Kunal says, ultimately the regulations were a good thing because there’s no ambiguity around operation hygiene or if anyone was “operating on the wrong, morally grey side of the law."

![Bnpl](https://images.yourstory.com/cs/2/f49f80307d7911eaa66f3b309d9a28f5/Image9ib7-1658643489431.jpg?fm=png&auto=format)

## Open and collaborative

While customer protection and welfare were at the crux of the RBI’s framework, startup founders *YourStory* spoke to said they appreciated the clear distinction between the RBI’s definition of a ‘credit line’ and a ‘loan’, which have been largely used interchangeably so far.

Also, clarity around the fact that credit card startups were essentially just a discovery and customer acquisition tool, and that heavily regulated banks were the actual custodians of customer data was helpful for the sector to reposition itself.

Higher-level talks on how customer data would be stored and managed by credit-focused B2C startups had been going on for quite some time before the digital lending guidelines were announced, and there was a lot of confusion over which way the RBI would skew and how that would affect startups—so the clarification was a welcome change.

The DLG implementation and the way the RBI actively engaged with the fintech community, banks, and NBFCs, signalled that the regulator was willing to work with the ecosystem and for the ecosystem, as long as consumer welfare was the nucleus—a very positive sign that the central bank was keeping a keen eye on the goings-on.

## What’s next

After digesting the concerns and questions from the industry, the RBI’s Working Group of Digital Lending (WGDL) is putting together a frequently-asked-questions (FAQ) document—to be published soon—that essentially addresses and clarifies any confusion around the guidelines.

Sources say that the follow-up notification could also provide clarity on the specific language the RBI wants startups to use in their communication with users, so users know what they’re signing up for and how their data will be used.

One source told *YourStory* that even though app-based BNPL startups were largely spared in the first set of guidelines—they essentially only needed to change some of their language right now—the RBI could look at tightening the way loans are being underwritten on these platforms.

Essentially, startups like LazyPay, KreditBee, Simpl, and others in their ilk issue small credit on the checkout page—just before you’re about to confirm your order, for example. While these platforms claim to have superior AI/ML-driven underwriting algorithms that take into account a user’s repayment history, spending patterns, and general financial hygiene, the regulator could be concerned about even a Rs 2,000 loan that could balloon into an unmanageable, long-term risk.

![Bnpl](https://images.yourstory.com/cs/2/f49f80307d7911eaa66f3b309d9a28f5/shutterstock1980115799-1658644477907.png?fm=png&auto=format&w=800)

“The RBI is worried about some bad apples rotting the entire system,” said a member of a fintech association who requested anonymity since the talks weren’t public.

> **“Banks inherently hate capital risk so they can be trusted to make sound decisions while underwriting. But startups or loan enablers need to prove their metrics to raise that next million-dollar funding round and therefore may be open to riskier bets. The RBI is not likely to be okay with the systemic risk bad borrowers pose,” they said.**

However, the source added that the discussion around underwriting practices was still confined to the sidelines, but, privy to internal thinking, said this could be formally brought before the RBI soon.

RBI did not respond to YourStory’s request for comment.

Although naysayers will continue to rail against the RBI’s regulatory step saying it stifles innovation, others see loans and lending take on a more ubiquitous form, thanks to co-lending.

“There are a lot of unexplored ways in which new-age companies can meet customer demands. Co-lending for specific use-cases for life events such as hospitalisation, education, and purchase of electric vehicles…basically more structured loan products, is definitely a good value proposition,” says Sugandh Saxena, CEO of Fintech Association for Consumer Empowerment (FACE).

“I’d definitely also like to see more done to enable women to access loans in a safe and secure manner,” she added.

For a country like India which is evolving at breakneck speed, regulations are like protective speed bumpers that ensure you’re speeding, but not at levels that could end up hurting you or someone else.

The RBI is moving in the right direction, and there will be some teething issues, but we’ll get there…there has to be a fine balance between regulation and flexibility, but we’ll get there, added Kunal.