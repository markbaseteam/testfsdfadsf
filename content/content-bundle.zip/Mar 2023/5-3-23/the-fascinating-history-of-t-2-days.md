 # The fascinating history of ‘T+2 days’   
 --- 
[T+2 days](t-2-days.md) , [stock market terms](stock-market-terms.md)    
   
This week's educational piece was written by [Jed Herne](jed-herne.md) .   
![837eb10f-da4d-02bb-be1f-11edee3cc563.jpg](files\837eb10f-da4d-02bb-be1f-11edee3cc563.jpg)    
When you place a trade for a share, there’s two key dates involved:   
1. **Transaction date**: the day you make the purchase.   
2. **Settlement date**: the time when ownership of the stock is transferred to you, and the money leaves your account.   
   
Most modern online brokers have a ‘T+2’ delay - which just means settlement takes place 2 business days after transaction.   
**But this wasn’t always the case**…   
In the 1700s, the first stock settlements occurred over a fortnight between the London Stock Exchange and the Amsterdam Stock Exchange (shares were cross-listed and traded between them). This settlement period allowed for the two weeks it took a horseback rider and ship to deliver the certificate of stock.   
Likewise, the New York Stock Exchange (which started in 1817) had a huge variety of settlement times until 1968, when Wall Street was dealing with so much paperwork that the exchange typically closed on Wednesdays just to settle all outstanding trades. Around this time, the settlement period was 5 business days (T+5).   
As fax machines became more popular, settlement times shrank. In 1993, the US Securities and Exchange Commission mandated a change to T+3, noting that:   
“Unsettled trades pose risks to our financial markets, especially when market prices plunge and trading volumes soar. The longer the period from trade execution to settlement, the greater the risk that securities firms and investors hit by sizable losses would be unable to pay for their transactions.”   
It makes sense... 5 business days is a long time!   
Imagine if someone pledges to spend $1m on a stock on Monday, but then suffers a bunch of bad trades throughout the week. When the following Monday (the settlement date) rolls around, they might not have the cash to fulfil their promise.   
**Future predictions**:   
Back in 2016, the ASX dropped their mandated delay from T+3 to T+2.   
With the increasing efficiency of online brokers, there’s a strong likelihood that we’ll reach a T+0 system in the future. This would further reduce market and credit risk.   
