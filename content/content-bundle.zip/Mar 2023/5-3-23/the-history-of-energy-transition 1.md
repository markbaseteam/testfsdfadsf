 # The history of Energy transition    
 --- 
[energy](energy.md) ,   
   
![image.png](files\image_r.png)    
Here’s an interesting graph showing how the world’s energy production has evolved over the last 200 years. Click the image to see a bigger format.   
- Each new ‘energy revolution’ (coal, then oil, then gas, although to a lesser extent) added massive amounts of total energy to the world’s energy mix.   
- Renewables are a minor portion (for now) - but could they do the same?   
