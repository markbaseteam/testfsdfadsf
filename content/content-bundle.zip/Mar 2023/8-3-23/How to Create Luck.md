Tag :- [[ReadItLater]] , 
Added :- 2023-03-08

-----
# [How to Create Luck](https://www.swyx.io/create-luck)

*Translations: [Español](https://blog.rauljimenez.info/es/c%C3%B3mo-crear-suerte). Discussions on [Hacker News](https://hn.algolia.com/?q=https%3A%2F%2Fwww.swyx.io%2Fcreate-luck%2F).*

My entire worldview changed when I realized that **luck can be created**.

More precisely, you can actively **create optimal conditions for lucky things to happen to you**. The more I looked into this, the more I realized that this is not only *not* a new insight, but successful people have studied this for *decades* and I am just late to the party.

In this post we’ll briefly review the “Literature of Luck”, and then I’ll end with some personal thoughts on how it could be extended.

## [Binary Luck](https://www.swyx.io/create-luck#binary-luck)

Most people have a binary view of luck:

![Alt Text](https://dev-to-uploads.s3.amazonaws.com/i/kgd335km9x3ujfmhxnz7.png)

This is true enough. Some people are born into privilege, some people just win some literal or figurative lottery or other.

The closing question of every episode of Guy Raz’s [How I Built This](https://www.npr.org/podcasts/510313/how-i-built-this) podcast asks successful people: *“How much of your success is due to skill, and how much is due to luck?”*

Those who believe in their own agency answer the former. Others - who’ve seen people smarter and harder working than them fail - answer the latter. Those who are politically correct cop-out with the half-and-half.

It can be comforting to subscribe to the binary luck model. If you just got a bad roll of the dice, there’s nothing you could do. Your lack of success is not your fault.

But what if I told you **there are people who have skill at creating luck** for themselves?

## [Luck Surface Area](https://www.swyx.io/create-luck#luck-surface-area)

Jason Roberts coined the term ”[Luck Surface Area](https://www.codusoperandi.com/posts/increasing-your-luck-surface-area)”, and it was expanded by [Sean Murphy](https://www.skmurphy.com/blog/2019/04/03/increase-your-luck-surface-area-to-get-more-customers/) and popularized by [Patrick McKenzie](https://www.perell.com/podcast/patrick-mckenzie-internet-famous).

I liken this model of luckiness to a “catchment area” ([a term from urban and hydrological geography](https://en.wikipedia.org/wiki/Catchment_area)). Luck is still randomly occurring, but you can position yourself in a way that captures more of it:

![Alt Text](https://dev-to-uploads.s3.amazonaws.com/i/ogbkk8weenqb9nltrl34.png)

Jason has a really simple model of how to grow your LSA - do more things, and tell more people about it. **Doing and Telling**. Already this embodies a more active attitude toward how you can orient your life for more positive random events. It’s ”[Fixed vs Growth mindset](https://www.brainpickings.org/2014/01/29/carol-dweck-mindset/)” adapted for luck.

> 2021 update: a reader [visualized the LSA concept with this fancy video](https://twitter.com/elzr/status/1381105950602461189)!

## [Four Kinds of Luck](https://www.swyx.io/create-luck#four-kinds-of-luck)

A parallel, older school of thought dates back to James Austin in 1978 and was repopularized by [Marc Andreesen](https://pmarchive.com/luck_and_the_entrepreneur.html) in 2007, then [Naval and Nivi](https://twitter.com/nivi/status/1094940675353784320?lang=en) a decade later.

Here, there are no helpful visuals. James Austin just gives a list of types, and Marc quotes verbatim. [Naval summarizes](https://twitter.com/naval/status/1093981014920052736) the 4 kinds of luck as such:

> 1.  Hope luck finds you.
>     
> 2.  Hustle until you stumble into it.
>     
> 3.  Prepare the mind and be sensitive to chances others miss.
>     
> 4.  Become the best at what you do. Refine what you do until this is true. Opportunity will seek you out. Luck becomes your destiny.
>     

I’ve quoted this many times to friends and always had trouble remembering what the 4 types are. I gave it some thought and visualized/organized it as such:

![Alt Text](https://dev-to-uploads.s3.amazonaws.com/i/5ycsicfgoxsvxoyys5ip.png)

1.  **🌱 Accidental Luck**: You have the same luck as a plant. A plant does not move. Whether or not a plant does well pretty much just depends on where it’s seed lands. It’s not very interesting since by definition you can’t do anything about it, but ofc privilege plays a huge part.
    
2.  **🏃🏽‍♀️ Active Luck**: The luck you get from constantly moving around. There’s no particular direction in mind, but you’re more likely to find something good if you move around and explore instead of stay put and hope. You’re more likely to roll a 6 if you roll more dice.
    
    > “I have never heard of anyone stumbling on something sitting down.” - [Charles Kettering](https://due.com/blog/keep-going-charles-f-kettering/)
    
    > “You don’t get extreme results without extreme actions.” - [Derek Sivers](https://sive.rs/extremex)
    
3.  **💊 Prepared Luck**: The luck you get from noticing that something lucky has happened, that most would miss. The canonical story on this is Alexander Fleming’s discovery of penicillin, which was a huge medical breakthrough. The discovery was a total accident (some mold happened to fall in the right spot + Fleming happened to see it + he had a similar experience that was a nonevent 9 years ago), but Fleming was not only “uniquely equipped to observe it” by his background, he took action to confirm the observation.
    
    > “Luck is what happens when preparation meets opportunity.” - Seneca
    
    > “Chance favors the prepared mind.” - Louis Pasteur
    
    > “Richard Feynman was fond of giving the following advice on how to be a genius. You have to keep a dozen of your favorite problems constantly present in your mind, although by and large they will lay in a dormant state. Every time you hear or read a new trick or a new result, test it against each of your twelve problems to see whether it helps. Every once in a while there will be a hit, and people will say: “How did he do it? He must be a genius!”” - [Gian-Carlo Rota](http://themattheweffect.org/tag/richard-feynman/)
    
4.  **🧲 Magnetic Luck**: *“Chance IV comes to you, unsought, because of who you are and how you behave.”* All sources call it “individualized action” but I’ve renamed it “magnetic luck” to emphasize the end result rather than how you get there. I’m quite familiar with this as [the “Miner” gear of my Learning Gears](https://www.swyx.io/writing/learning-gears/#miner) terminology (since updated to 4 gears in [my book](https://learninpublic.org/)). This was already a thing pre-Internet, but search and social media have given tremendous reach and influence to the oddballs and obsessives that become the spiritual leaders of every idea and purpose both big and niche.
    

I find the 4 of these hard to remember, so I’ve organized them along two axes - **active vs passive**, and **general vs individual**. The first axis is the same realization as “Luck Surface Area” - you actually have the power to do things to create more luck than you were given.

The second axis is the insight - that there are forms of luck that apply to everyone, and there are forms of luck that are available only to someone in your unique position. There is a you-shaped hole in the universe and you can either passively occupy it or you can become a beacon for some idea or purpose.

## [Habits and Strategy](https://www.swyx.io/create-luck#habits-and-strategy)

I of course find the Four Kinds of Luck very appealing, since I’ve quoted it so much to friends that I’m writing this post at all. But upon closer reading I think there’s a *slightly* different direction that is unaddressed by the Four Kinds (I originally thought this was embedded in the Four Kinds, only to discover that it wasn’t in the source material and I had completely read my own thinking into it).

![Alt Text](https://dev-to-uploads.s3.amazonaws.com/i/poue5zg9homy1eo4ml05.png)

This model differs in two ways. It treats both axes as a spectrum rather than a 2x2. It also focuses more on **actions** (you can take) rather than **classification** (which are a little more abstract). I’ve also swapped out “Active vs Passive” for “Active Habits” and “Individual vs General” for “Good Strategy”. So my version is more about HOW you get more lucky. It’s not very actionable to be “more magnetic”, but you can Claim a Domain or Hustle and have a good sense of what those things entail.

I’ve written about a few of these ideas in prior posts so I won’t elaborate:

-   [Claiming a Domain, Personal Branding](https://www.swyx.io/writing/marketing-yourself/)
-   “Copywork” I wrote about in the “Clone Open Source Apps” chapter of the book

I think **Exploring** and **Prospecting** are worth elaborating here.

**Exploring** (and to a lesser extent Grinding and Copywork) are **Actively Habitual, non Strategic** activities. But this doesn’t mean it is bad. I think this is what you do when you take in general life and career advice and apply them to yourself. You know there are a list of **Principles** which are just generally good things to do in life, and trust that you will do well if you do those things (e.g. [Learn in Public](https://www.swyx.io/writing/learn-in-public/)). Keep doing the “right” things, and “trust the process”.

**Prospecting** is a term I’ve [borrowed from the oil exploration industry](https://en.wikipedia.org/wiki/Prospecting). **Prospecting is a highly Active habit, and highly Strategic.** These days, when you look for oil, there is a whole science to handicapping whether or not a plot of land is likely to have oil. You don’t know it for a fact, all you’re doing is estimating probabilities. Not to get too tautological, but you will be luckier if you can consistently assess and move towards areas where you are more likely to be “lucky”. It might look like luck to others, but the motion and intention you invested to get yourself in a position to be lucky was far from random. I’ve also written many times about how I think strategic [manoeuvring for “Megatrends”](https://www.google.com/search?&q=swyx.io+%22megatrends%22&oq=swyx.io+%22megatrends%22) is a good idea.

## [In Summary](https://www.swyx.io/create-luck#in-summary)

![Alt Text](https://dev-to-uploads.s3.amazonaws.com/i/5075sq79y4pstxpp4pdk.png)

This is the state of my thinking on luck right now. That last bit you just read is pretty fresh, I might come back and change this in a couple years when I have refined my thoughts. I welcome any and all feedback.

But overall, the message I really want to leave you with is this: **you can create luck**. That’s it. I don’t care how you do it, what mental model you use, who you quote. I just care *that* you do it. **Go make yourself more lucky.**

> Ordinarily I’d wish you good luck, but now you have something better than a mere wish 😂

-   The Serendipity Mindset: The Art and Science of Creating Good Luck ([Book](https://www.amazon.com/gp/product/B0818ZH58R/ref=as_li_tl), [Podcast](https://www.artofmanliness.com/articles/podcast-662-the-art-and-science-of-creating-good-luck/))
-   [How To Get Lucky](https://www.navalmanack.com/almanack-of-naval-ravikant/how-to-get-lucky) in the Alamanack of Naval Ravikant
-   [How to Maximize Serendipity](https://www.perell.com/blog/serendipity) by David Perell
-   [Richard Meadows - Optionality: How To Make Your Own Luck In Life](https://modernwisdom.libsyn.com/269-richard-meadows-optionality-how-to-make-your-own-luck-in-life)
-   GitHub ReadME project: [Publishing your work increases your luck](https://github.com/readme/guides/publishing-your-work) (see [HN comments](https://news.ycombinator.com/item?id=32071137))
-   Richard Wiseman’s [4 precursors of Luck](https://www.youtube.com/watch?v=lKxFDqP1Yw4) (Open to Opportunities, Intuition, Optimists, Resilient)