Tag :- [[ReadItLater]] , #aws 
Added :- 2023-03-08

-----
# [AWS Cost Optimization Guide](https://www.microtica.com/aws-cost-optimization)

## INTRODUCTION

How well does your company handle cloud costs? While you could have spending statistics at your disposal that will reassure you that the production team is under its monthly budget or that your monthly recurring income is on an upward trajectory, this data does not actually mean that you are handling investments in the cloud as well as you should be.

[RightScale and Flexera](https://www.flexera.com/blog/cloud/cloud-computing-trends-2022-state-of-the-cloud-report/) teamed up to research the cloud spending habits of companies. What they found was that 35% or even higher of cloud spend is wasted. In times when nothing is certain and when a pandemic has taken over the world, companies are very careful with their spending. Saving the resources you normally waste on cloud spend could open new possibilities for product improvement and growth.

To hit you with some more numbers, 61% of companies are prioritizing cloud cost optimization this year, which makes it a number one initiative once again. Another top-three initiative is getting better financial reporting on cloud costs.

It is not uncommon to see reports stating that companies are overspending on the cloud. They are losing tons of money on unused assets and consuming more capacity assets than they need. Rightsizing, arranging, and obtaining Reserved Instances for predictable workloads are some of the practices that AWS users often leverage to reduce their cloud costs.

However, these options might not be the only solutions. Every year there are new initiatives, tools, and best practices for AWS cost optimization that, when used right, could save you a lot more.

In this article, we want to enable you to approach AWS cost optimization and offer viable solutions that reduce AWS costs efficiently. Let’s start by defining an AWS cost optimization strategy.

‍

## CHAPTER 1:  
Create an AWS Cost Optimization strategy

Costs and expenses are two different things. Expenses are what is required for a business to continue to operate and costs are associated with the delivery of final products. Costs can be fixed or variable, depending on the production of the company.

Dividing costs into fixed or variable can help identify where you can spend less. Analyze your requirements: What kind of storage you need? How much? What will your day-to-day operations look like?

Much like production lines try to identify which products are decreasing their production and not selling, you can identify projects that are not performing like you’ve anticipated and don’t need the scaling requirements set in the beginning. Decrease those production instances and storages and auto- scale when needed.

![](ReadItLater%20Inbox/assets/63515734fd13f1778846c8a3_Screenshot%202022-10-20%20at%2016.11.50.png..png)

The most important thing here shouldn't be the costs you cut, but where you can focus the resources to increase growth. This is called strategic cost reduction.

**Key takeaway:** Define which costs are strategically critical to the operation of your business. Everything else can either be decreased or cut completely, as they are non-essential costs.

Our second chapter walks you through Understanding the AWS costs.

## **Define your goals**

Always get into something with the end goal in mind. To successfully adopt a cost reduction strategy, making a plan is first and foremost.

Do a lot of research and analysis on your business and the goals you want to achieve. Specify monthly, quarterly, yearly goals or a definite date that makes sense for your situation.

You can set up cost avoidance goals by teams. If there are teams that use a lot of compute and storage power, by looking at recommendations for rightsizing you can create targets for the team to optimize the workloads and follow the process. This is more effective than simple waste reduction, as it helps teams make intelligent decisions about the cloud needs.

Like any other initiative in the company, there needs to be direction and leadership. Cost optimization should be considered as a strategic move for the whole business. So talk to your colleagues and superiors and make sure you’re all on the same page.

But the most important goal here could be to create a cost-effective environment. Development teams should be enabled to understand cloud finance and economics. A good start is to obtain [a cloud certification from AWS](https://aws.amazon.com/economics/) to be able to have discussions and implement cost management in the company.

**Key takeaway:** Everyone in the company should be aware of the cost optimization goals. Enabling teams to get more insights into cloud economics will create a cost awareness culture, which is the most important goal.

## **Practice makes perfect**

With the specified goals in mind, an execution plan is the logical next step. But with millions of compelling initiatives you can do, how do you prioritize cost optimization recommendations and decide on the best ones for you?

The most simple way to make a decision can be to look at two parameters: the benefit and the investment.

The benefit looks at the estimated potential savings you can get by implementing the recommendation.  
The investment looks at the estimated level of work that is required to implement the recommendation. This can be seen from a time and resource perspective, customer impact and/or technical risk to the system.

Here is an example of how you can look at the parameters:

![](ReadItLater%20Inbox/assets/63515c293885ea5c6850246c_image-1.png..png)

Once you assign a score value to each idea you’ll be able to get a prioritization board which will ultimately be the foundation of your implementation plan. It could look like this:

![](ReadItLater%20Inbox/assets/63515c405bdb3903840a265e_image-2.png..png)

**Key takeaway:** Prioritizing initiatives will give you a direction and will set things into perspective. You will understand what is feasible for your short-term and long-term goals. This will be the first step toward the actual implementation plan.

You can find recommendations for cost optimization in Chapter 3.

## Measure and improve your strategy

In order to be able to measure the success of your strategy, you need to define some metrics to guide you. Some cost management metrics that can help you track costs more effectively are:

-   **Monthly growth -** how efficiently your AWS implementation is rising in terms of the total costs
-   ‍**Provisioned capacity & use -** this will help you identify cloud waste
-   **Amazon EC2 unit and instance expenses** - EC2 accounts for a greater portion of your expenses compared to other services
-   ‍**Expenses for unused resources -** this should be something that is decreasing when you have visibility into unused resources
-   ‍**Data retrieval costs -** you should be able to identify how much of your object storage charges are susceptible to data retrieval

You can read in detail about the 9 KPIs for measuring success with AWS savings [here](https://www.microtica.com/blog/9-kpis-for-measuring-success-with-aws-savings).

Establish a continuous cost control by tracking these metrics over time and recognizing patterns for improvement.

**Key takeaway: Implement tools and dashboards to be able to monitor your performance for your defined metrics. Create a process to review the results against your defined goals and improve your strategy.**

‍

## CHAPTER 2:  
Understand AWS costs

A successful approach to AWS cost optimization starts by gaining a thorough view of the existing costs, finding potential for cost optimization, and incorporating modifications. AWS and other providers of software have resources to help clients understand how they are spending.

In this article, we provide a comprehensive guide on how to understand your AWS costs and needs.

## **What are your data storage requirements?**

The first step is to consider the performance profile for each of your workloads in order to maximize storage. To calculate input/output operations per second (IOPS), throughput, and other metrics you need for this analysis, you can conduct a performance evaluation.

AWS storage services are configured for various situations related to storage.

There’s no one data storage solution that is suitable for all workloads. Evaluate data storage solutions for each workload independently when determining the storage requirements.

To do this efficiently, you should identify some key information.

![](ReadItLater%20Inbox/assets/63516294968681b04cc18f4b_image-3.png..png)

‍

![](ReadItLater%20Inbox/assets/635162fef376334bd7662013_image-4.png..png)

## S3 storage classes

S3 storage classes affect the availability, lifetime, and spending on objects stored in S3. Every S3 bucket can store objects with different classes, which can be modified and changed during their lifetime. Picking out the right storage class is crucial to achieving cost-effectiveness. The wrong storage class can lead to many unnecessary costs.

Amazon S3 provides six storage classes, each built for specific use cases and available at differing rates. Each of them has a different cost per gigabyte.

-   **S3 Standard:** costs are based on object size. Store here the objects that you will be accessing frequently.
-   **S3 Standard-Infrequent Access:** costs are based on object size and retrieval.
-   **S3 One Zone-Infrequent Access:** the difference between this class and S3 Standard-IA is that it stores data in a single AZ at a 20% lower cost, instead of a minimum of three AZs. However, this reduces availability.
-   **S3 Intelligent-Tiering:** transfers objects between classes based on the frequency of use, charging per transfer. Used objects go to Standard, while infrequently used objects go to Standard-IA.
-   **S3 Glacier:** long-term data archiving, an additional storage at a lower cost.
-   **S3 Glacier Deep Archive:** long-term data archiving with access once or twice a year.

## EBS Storage

Elastic Block Store (EBS) represents storage for EC2 virtual machines. It can go up to 16 TiB per disk, offering SSD or HDD support. This is provisioned storage you pay per gigabyte, on a monthly basis. This means that you should try to estimate the amount of storage you need at a given time and only purchase that volume. You can increase the size of your EBS storage later.

When purchasing EBS storage, the first thing you should decide is whether to use SSD or HDD volumes. SSD volumes are great for regular read and write operations, while HDD is better with wide streaming workloads that require efficient throughput.

There are several types of EBS storage volumes. You can see a list of them [here](https://aws.amazon.com/ebs/pricing/).

When choosing the correct volume, the first thing that will probably come to your mind is to dismiss HDD storage, but don’t precipitate with your decision. If you decide on one of the SSD options, regularly monitoring your EBS storage can show you whether HDD would be a better choice, highlighting that you might not need that efficient performance after all. Also, don’t forget to turn off EBS storage volumes you no longer use. This can save you many unnecessary costs.

Here, we need to mention EBS snapshots as well. EBS snapshots represent a piece of the used space in the EBS storage, not the provisioned storage. They are also charged per gigabyte per month, at a price of $0.05 per GB-month of data stored. When you want to restore a snapshot, you can use EBS Fast Snapshot restore, but at a higher price.

You can start with the Free Tier that offers 30GB of EBS Storage, 2 million I/Os, and 1GB of snapshot storage.

## EC2 pricing

EC2 instances are charged per hour or per second while they are running. This means that when we don’t need them, we should shut them down.

Here, you’ll also have to pay for the provisioned EBS storage, regardless of whether your EC2 instances are running or not. Finally, you’ll also pay for data transfer out, a price that varies depending on the region. There are also other points of pricing you can find in the [EC2 documentation](https://aws.amazon.com/ec2/pricing/).

There are several types of EC2 payment options:

![](ReadItLater%20Inbox/assets/635163c2e15a40e04fad63e2_image-5.png..png)

There are about 400 EC2 instances you can choose from. It’s important to choose the right instance family and size in order to be cost-effective. For right-sizing, you can use Amazon CloudWatch, AWS Cost Explorer, and AWS Trusted Advisor.

## Cost savings in serverless

Serverless computing can save you a lot of time and money. Here are some of the benefits:

-   No need for server management
-   Scale automatically without downtime
-   Pay for what you use
-   Migrate a large amount of everyday work to AWS
-   Save time you can use to focus on your actual product
-   Become more agile and flexible

To become serverless on the AWS platform, you can use AWS Lambda for computing, DynamoDB or Aurora for data, S3 for storage, and the API Gateway as a proxy.

## Database pricing (RDS & DynamoDB)

When it comes to RDS pricing, the first thing to think about is the instance you choose. The only serverless option is Amazon Aurora. Next, database storage is also an important factor. Obviously, the bigger the database, the bigger the cost. The remaining two factors are backup storage and data transfer between availability zones and storage.

You can choose one of the following [Amazon RDS instances](https://aws.amazon.com/rds/instance-types/):

-   General purpose (T3, T2, M6g, M5, M5d, M4)
-   Memory optimized (R6g, R5, R5b, R5d, R4, X1e, X1, Z1d)

You can try Amazon RDS for free and pay for what you use. The payment options are on-demand or Reserved Instances. To estimate your spendings, try the [Pricing Calculator](https://calculator.aws/).

As for DynamoDB, you can also pay on-demand or for provisioned capacity. You can see the difference between read and write capacity units depending on the pricing type [here](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/HowItWorks.ReadWriteCapacityMode.html).

To affect the costs you’ll have for DynamoDB, use auto-scaling. Auto-scaling uses traffic patterns to dynamically adjust the number of read and write capacity units, which in fact helps with the difficulty to predict DynamoDB workloads. By defining a scaling policy for read/write capacity you only enter the minimum and maximum values for provisioning. With alarms, you can trigger the autoscaling policy to perform certain steps in order to scale up or down.

To save more, you can purchase reserved capacity units for a period of one or three years. This commitment will allow you to get capacity units at a reduced price.

## Key takeaways

To choose the right AWS pricing plans, you need to understand your data storage requirements first. The importance, delicacy, and amount of data, as well as other characteristics, will impact the final AWS spendings you’re going to have.

Then, you need to choose from the six storage classes AWS has to offer, as well as EBS storage volumes. There are also several EC2 pricing plans and choosing serverless computing as an option. Finally, we’ve explained Amazon RDS and DynamoDB pricing. What you choose depends on your application and your data storage requirements.

‍

## CHAPTER 3:  
Recommendations to get you to bigger savings

You need to take care of the economic model of the architecture while designing applications and workloads on AWS. Compared to on-premises data centers, it is necessary to look beyond the fundamental pricing benefits and explore ways to leverage the infrastructure successfully to lower your AWS charge.

Regardless of whether you’re going to hire a FinOps professional or handle the process within the existing team, here are the best practices for AWS cost optimization:

## Apply for AWS credits

AWS credits are one of the most common ways to save on your AWS bill. They represent something similar to a coupon code, which can help you cover costs with AWS services. You can use them until you spend them all or until they expire. There are various ways to get AWS credits, here are some:

-   [**AWS Activate**](https://aws.amazon.com/activate/) **-** for startups to set up infrastructure as quickly as possible
-   [**AWS Activate Founders**](https://aws.amazon.com/activate/founders/) **-** for startups that haven’t raised any venture capital, seed, or angel funding
-   [**Publish Alexa skills**](https://developer.amazon.com/en-US/alexa/alexa-skills-kit/new/aws-promotional-credits) **-** for each Alexa skill you publish, you can apply for $100 AWS promotional credits
-   [**Attend AWS events and webinars**](https://aws.amazon.com/events/) **-** here you can find many opportunities for AWS credits
-   [**AWS Educate**](https://aws.amazon.com/education/awseducate/) **-** educators earn $200 in AWS credits, while students can create a starter account with up to $100 in credits at a member institution
-   [**AWS for Nonprofits Credit Program**](https://aws.amazon.com/government-education/nonprofits/nonprofit-credit-program/) **\-** this program provides access to $2,000 for nonprofit organizations
-   [**AWS EdStart**](https://aws.amazon.com/education/edstart/faq/) **-** for education technology startups
-   ‍[**AWS Free Tier**](https://aws.amazon.com/free/?all-free-tier.sort-by=item.additionalFields.SortRank&all-free-tier.sort-order=asc) **\-** a program that includes 85 products for businesses to start building on AWS, explained in details in the next section
-   Product Hunt - [**Product Hunt’s Ship platform**](https://www.producthunt.com/ship/aws) allows startups to claim up to $7,500 in AWS credits
-   [**Use Secret deals**](https://www.joinsecret.com/offers/aws-activate-promocode-100000-9dc4ecaa-359e-48ff-be92-a08cbf919b36)
-   [**F6S deals**](https://aws.amazon.com/education/awseducate/)
-   [**Brex**](https://www.brex.com/product/rewards/) **-** if you use Brex cards, there are many benefits, including up to $5,000 in AWS credits
-   [**Startup School**](https://www.startupschool.org/) **-** if you’re a startup, Startup School can bring you a deal with free AWS credits

## **Utilize AWS Free Tier**

Cloud platforms provide a number of services for free in the beginning, but even free services have an upper limit. The services become billable as soon as consumers hit the cap. These services are used on a daily basis by people new to cloud computing and before they fully transition to the cloud environment. Many free cloud plans come with an expiry date and the payment period begins as soon as it ends.

For example, Azure offers a free tier plan for a month, giving the possibility to run two small virtual machines with a storage capacity of 800GB. Google Cloud, on the other hand, offers $300 credit for a period of 12 months, when users can use services like Google App Engine or Google Compute Engine. AWS’s free tier plan lasts for 12 months, giving services like EC2, S3, and AWS RDS.

The Free Tier extends to a limited number of AWS offerings and is subjected to a monthly consumption cap. The AWS Free Usage Tier is divided into three pricing models: a 12-month Free Tier, an Always Free offer, and brief trials.

![](ReadItLater%20Inbox/assets/635166e841c8774ca4dfeb17_image-6.png..png)

Some of the services available include 750 hours of Amazon EC2 Linux, 750 hours of an Elastic Load Balancer, 750 hours of Amazon RDS Single-AZ Micro DB Instances, 5 GB of Amazon S3 standard storage, 10 Amazon Cloudwatch metrics with 1,000,000 API requests, and others. You can see all the services and limitations here.

For example, [the AWS Free Tier model was used at a college](https://www.infoworld.com/article/3585757/how-to-make-the-most-of-the-aws-free-tier.html) to teach students about web frameworks. However, you can use it for much more. This model can allow you to build and maintain a basic web application. [This example by AWS](https://aws.amazon.com/getting-started/hands-on/build-web-app-s3-lambda-api-gateway-dynamodb/) can guide you through making an app with AWS Amplify, Amazon API Gateway, AWS Lambda, and Amazon DynamoDB. Moreover, you can connect it to a serverless backend and add interactivity with an API and database.

## Choose the right AWS region

When you set up your AWS modules, picking an AWS region is the first choice you have to make. Without picking a region, you can’t start working on the AWS Management Console, SDK or CLI. People usually choose the region according to distance, which is the most obvious choice. However, there are many other factors to consider. Here are some of them:

-   Costs - different regions have different AWS rates, check the [cost calculator](https://calculator.s3.amazonaws.com/index.html) to count your costs for a particular region
-   Latency - choose a region with a smaller latency to make the app more accessible to your target customers
-   Security - check the regulations of each region before deciding to choose it
-   Service availability - not all services are available to all regions, so make sure you know which ones you need before choosing a region
-   AZ availability - also, not all regions have the same number of availability zones

The best solution would be to choose the factor that is the most important for you and use it as a guide to choose your particular AWS region.

## **Use AWS Savings Plans**

[The AWS Savings Plan](https://aws.amazon.com/savingsplans/) was introduced in November 2019, as a flexible pricing plan that allows consumers to save up to 72% on Amazon EC2 and AWS Fargate in return for a 1 or 3-year contract commitment to a consistent amount of compute use (e.g. $10/hour).

You can start using this feature directly from the AWS Cost Explorer control console or using the AWS API/CLI. Here's how you can pay:

-   On a monthly basis, with no upfront payment
-   On a monthly basis, with paying at least half of the commitment price upfront
-   Upfront, paying the entire commitment with one payment and achieving the highest savings

For example, if you commit to a usage of $10/hour, you get discount prices on all your usage up to $10 and any usage beyond this commitment will be charged at regular on-demand rates. There are two types of Savings Plans:

![](ReadItLater%20Inbox/assets/635167f1f71ec220300bcecf_image-7.png..png)

Analyze [AWS’s guides to the Savings Plan](https://docs.aws.amazon.com/cur/latest/userguide/cur-sp.html) and try to choose the best setup for your specific case.

## **Analyze your AWS bill**

Tools like [Cost Explorer](https://aws.amazon.com/aws-cost-management/aws-cost-explorer/), [Cost & Usage Report](https://aws.amazon.com/aws-cost-management/aws-cost-and-usage-reporting/), [Trusted Advisor](https://aws.amazon.com/premiumsupport/technology/trusted-advisor/), or [Cost Optimization Monitor](https://docs.aws.amazon.com/solutions/latest/cost-optimization-monitor/welcome.html) to analyze your AWS bill and see how you are spending your budget. Research all categories of your bill and understand what they mean. Contact AWS Support if you find anything you can't understand, and they'll help you find the answer. It will be easier to separate some kinds of expenses from others by using various AWS accounts for AWS entities and centralized billing.

## **Single billing for all accounts**

Getting a single bill is very convenient for tracking expenses and monitoring spending if you have several accounts. This helps you get an overview of all AWS costs accrued across all your accounts with a consolidated view.

There's no extra charge for this service. In the unified billing family, the Master Account pays the costs that all the other accounts accumulate. You can easily trace the costs from each account, and the expense data can also be accessed in a CSV file.

## Create billing alarms

To warn you when your AWS bill exceeds critical stages, generate billing alarms. Be sure you have many warning thresholds: when the bill rises a little bit, when the bill rises a lot, and when the budget is way over the limit.

## **Use reserved instances optimization**

This option checks the usage history of Amazon EC2 computing and estimates an ideal size of partial cumulative reserved instances. Guidelines focus on hour-by-hour use of the preceding calendar month gathered across all combined billing accounts. It is an integral feature of cost optimization that helps you to estimate the number of hours of use you need this month depending on the sum of previous months.

![](ReadItLater%20Inbox/assets/635169acb2834c5c3cc90e86_image-8.png..png)

With this option, you commit to purchasing a reservation for one or three years. There are three payment alternatives: full upfront, partial upfront, and no upfront. The last two allow you to pay the remaining balance monthly during the period.

## **Pay-as-you-go**

Pay-as-you-go is a straightforward idea that does not include minimum obligations or long-term contracts. You substitute low operating costs for the upfront capital spending and just compensate for what you need. There is no need to pay for unused space in advance or get fined for wrong estimations. This is one of the key cost optimizations of the service side inherent in AWS's pricing strategy.

## **Turn off unused instances by creating schedules**

In order to optimize costs, it is crucial to shut down unused instances, particularly at the end of the working day or on weekends and vacations. For non-production instances such as those used for development, staging, monitoring, and QA, it is worth preparing on/off-hours. For example, implementing an "on" mode from 8.00 a.m. to 8.00 p.m. from Monday until Friday until Monday, large expense volumes can be avoided, particularly if production teams work during flexible hours.

Through evaluating usage metrics to decide when the instances are more widely used, you can implement more intense schedules or apply an always-stopped schedule that you can disrupt when you need access to the instances. It is important to figure out that you are already paying for EBS quantities and other elements connected to them while instances are set to be off.

## **Choose the right storage class**

Amazon S3 provides six storage classes, each built for specific use cases and available at differing rates.

-   **S3 Standard:** for frequently accessed data with low latency and high throughput performance.
-   **S3 Standard-Infrequent Access:** for infrequently accessed data that needs rapid access at times.
-   **S3 One Zone-Infrequent Access:** the difference between this class and S3 Standard-IA is that it stores data in a single AZ at a 20% lower cost, instead of a minimum of three AZs.
-   **S3 Intelligent-Tiering:** transfers data to the most cost-effective access rate immediately without overhead control.
-   **S3 Glacier:** long-term data archiving.
-   **S3 Glacier Deep Archive:** long-term data archiving with access once or twice a year.

The choice depends on your data needs and requirements, as well as your budget. Consider introducing object lifecycle management that moves data between the storage classes dynamically to optimize the cost of your data storage.

## **Intelligent tiering**

S3 Intelligent Tiering was created for teams that want to automatically adjust costs when data access patterns change, eliminating the risk of performance bottlenecks and overspending. The model automatically delivers cost savings by storing objects in two access tiers: frequent access and infrequent access.

S3 Intelligent-Tiering tracks access habits and transfers objects that have not been accessed for 30 days to the infrequent access tier for a small monthly tracking and automation charge per object. In S3 Intelligent-Tiering, there are no retrieval costs. When an object from the infrequent access tier is accessed again, it is immediately transferred to the frequent access tier. As items are transferred between access levels within the S3 Intelligent-Tiering storage class, there are no additional tiering costs.

![](ReadItLater%20Inbox/assets/63524eba48917e3789d0d271_image-9.png..png)

## **Specify expiration dates**

AWS S3 allows you to define expiration dates for S3 objects, as well as rules to move objects to cheaper storage tiers. When the object reaches the expiration date, it has reached the end of its lifetime, so it’s removed asynchronously. This is known as the lifecycle expiration rule. As S3 doesn’t charge for the storage time of objects that have expired, this is a great way to eliminate some spendings that you don’t need.

There are some rules though:

-   For S3 Intelligent-Tiering, S3 Standard-IA, or S3 One Zone-IA storage the minimum expiration limit is 30 days, so if you define an expiration of less than 30 days you are still charged for 30 days.
-   For S3 Glacier storage the minimum is 90 days, so if you define it for less than 90 days to expire, you are still charged for 90 days.
-   For S3 Glacier Deep Archive storage if you define expiration for less than 180 days, you are charged for 180 days.

## **Choose the right instance type**

Because multiple types of instances can cost varying amounts, it is essential to make sure that your team is using the most cost-effective ones. You have to try to pick the instance that fits the workload of the program best.

When deciding variables such as the type of processing unit and the storage space required, remember your particular use case to optimize your workloads while reducing your spending. Configure the instance resource that produces price efficiency for the value being delivered. Review your choice of instances every few months to confirm they reflect the reality of your workload.

To be able to pick the right size for a resource there is a combination of AWS tools you can use. AWS Cost Explorer resource optimizer and AWS Compute Optimizer are services that can help implement a right-sizing plan.

The tools will observe your workload performance and capacity, like CPU and memory utilization and suggest instance types and sizes according to those parameters.

![](ReadItLater%20Inbox/assets/63524fc832434b12579926e8_image-10.png..png)

Consider that development resources don’t need to be the same size as production instances. So here you could save significantly, by downsizing the non-production environments, but not having impact on the performance you need to get the job done.

Categorizing your instance with tags can be a good solution too. It is possible to track the cost per hour of operating systems in real-time, measure them using tags, and these outcomes will motivate the production team to reduce costs.

## **A partnership between finance and technology**

This requires a cultural shift that will make finance and tech teams collaborate better. Cross-functional teams should work together to promote smoother implementation while gaining greater financial and corporate leverage at the same time.

This partnership should remove barriers between the two teams, providing a better overview of finances for the tech team. On the other hand, the financial department should get a clear image of how the tech team allocates its resources.

Engineering teams can more easily create better features, applications, and migrations. It also provides for a cross-functional debate of whether to invest and when. Often a company may expect to cut back on expenditures, while sometimes it chooses to invest more. Yet, teams have to know why the decisions are made.

To establish a closer relationship between the finance and technology departments, some companies adopt FinOps. FinOps manages cloud finances, with the goal to add more financial transparency to the variable expenditure model used by the company. This provides more balance between speed, costs, and software quality for teams.

FinOps enables all operating teams to access real-time data that they need to influence their spending and make wise decisions that ultimately lead to efficient optimization of cloud costs without impacting the final product's performance, speed, and efficiency.

## **Use AWS License Manager**

Companies seeking for an appropriate and constructive license management plan to remain consistent with license conditions, prevent costly over-provisioning, and make licensing true-ups and audits simpler by using existing software licenses. [The AWS License Manager](https://aws.amazon.com/license-manager/) allows users to easily manage licenses in AWS and on-premise servers from various software providers.

AWS License Manager gives administrators a consolidated view of license use so they can figure out how many permits they need and avoid buying more than they use. You will also monitor overpayments and escape license audit fines with this increased visibility. AWS License Manager is simple to use and saves time and money when it comes to monitoring and handling licenses.

## **How much impact do these recommendations have?**

After elaborating on the recommendations, we want to see how much impact some of them could have. Moreover, we also estimated their complexity. This way, you can decide which recommendations to choose based on how much time you’ll have to spend incorporating them and the effect you’ll have from them.

Simple and fast with low impact can be S3 intelligent tiering. This takes around 10-15 mins to turn on. This monitors your object data access and automatically figures out whether the storage should be in regular S3 (which costs more) or in infrequent access (which costs less).

Another simple but more impactful recommendation to do can be Savings Plan.

![](ReadItLater%20Inbox/assets/63525045a4961962c98db028_image-11.png..png)

Unfortunately, companies aren’t utilizing savings opportunities enough. For example, the Flexera 2021 State of the Cloud Report discovers that 52% of users use AWS Reserved Instances, while only 37% use AWS Spot Instances. However they are quickly adopting AWS Savings Plan (30% in 2020). Organizations have to move quicker and more efficiently to achieve more savings and reduce their cloud waste.

![](ReadItLater%20Inbox/assets/6352505e1039263c56dee25e_image-12.png..png)

## CONCLUSION

Every year, cloud usage is on the rise because of the advantages of cloud computing. In addition, for enterprises, the impacts on cooperation, security, development, and revenue are evident. However, additional actions companies take can significantly boost cost-savings.

Start by creating an AWS cost optimization strategy. To do this effectively, you first need to identify your existing costs. Highlight those that are necessary and try cutting the rest. Then, define your cost optimization goals. Conduct extensive research and study on the company and the objectives you wish to accomplish. Set targets for yourself on a weekly, quarterly, or annual basis, or on a specific date that works for you.

After you’ve defined your goals, it’s time to take some action. Choose the activities you’re going to take and prioritize them. Here is a list of the AWS cost optimization suggestions we mentioned in this e-book:

1.  Apply for AWS credits
2.  Utilize AWS Free Tier
3.  Choose the right AWS region
4.  Use AWS Savings Plans
5.  Analyze your AWS bill
6.  Single billing for all accounts
7.  Create billing alarms
8.  Use reserved instances optimization
9.  Pay-as-you-go
10.  Turn off unused instances by creating schedules
11.  Monitor and track your spendings
12.  Choose the right storage class
13.  Intelligent tiering
14.  Specify expiration dates
15.  Choose the right instance type
16.  A partnership between finance and technology
17.  Use AWS License Manager

Finally, monitor and measure your achievements. To be able to track your results with your specified metrics, implement tools and dashboards. Create a system for evaluating and improving your plan by comparing the outcomes to your established objectives.

And, don’t forget to iterate. Not everything that works for others will work for you. Modify and adjust your actions until you get the perfect formula of what saves you from paying enormous cloud bills.

You will realize long-term financial gains by taking measures to handle your cloud savings efficiently. This will help your business improve growth, repurpose more money for market research and development, and finally, for creating more user-oriented products and services.