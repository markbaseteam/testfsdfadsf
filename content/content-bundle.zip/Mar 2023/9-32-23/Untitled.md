9000 story view

