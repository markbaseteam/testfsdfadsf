[[ReadItLater]] [[Tweet]]

# [Daniel Okon](https://twitter.com/thedanielokon/status/1596230522069716992)

> Another great example of making the checkout a place of value.  
>   
> $100 threshold = free shipping 📦  
>   
> $150 threshold = free gift 🎁  
>   
> $250 threshold = 30% off 🤑  
>   
> This is great because it’s easy and simple and will help boost AOV AND delight the customer. Great work [@JambysTime](https://twitter.com/JambysTime?ref_src=twsrc%5Etfw) [pic.twitter.com/ct5KbA4yju](https://t.co/ct5KbA4yju)

![[Pasted image 20230221123408.png]]
> — Daniel Okon (@thedanielokon) [November 25, 2022](https://twitter.com/thedanielokon/status/1596230522069716992?ref_src=twsrc%5Etfw)